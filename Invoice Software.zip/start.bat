@echo off
title GST Invoice Pro - SQLite Database Server
cd /d "%~dp0"

echo ========================================================
echo        GST Invoice Pro - Database Server
echo ========================================================
echo.

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo [1/2] Starting Python with Inbuilt SQLite database...
    echo [2/2] Your default browser will open automatically.
    echo.
    echo Database File: data\invoices.db
    echo (Keep this window open while using the software)
    echo.
    python run_server.py
    if %ERRORLEVEL% NEQ 0 (
        echo.
        echo [Server stopped]
    )
    pause
    exit /b 0
)

where node >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo [1/2] Starting Node.js SQLite server...
    echo [2/2] Your default browser will open automatically.
    echo.
    echo Database File: data\invoices.db
    echo.
    start "" "http://localhost:3000"
    node server.js
    pause
    exit /b 0
)

echo [Warning] Neither Python nor Node.js detected in PATH.
echo Opening application directly in web browser (Offline mode)...
start "" "%~dp0index.html"
pause
