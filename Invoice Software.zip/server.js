// ========================================================
// GST Invoice Pro - Database Server (Node.js & SQLite)
// Zero external dependencies required (Node 22+ built-in)
// ========================================================

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const PORT = process.env.PORT || 3000;
const ROOT_DIR = __dirname;
const DATA_DIR = path.join(ROOT_DIR, 'data');
const DB_PATH = path.join(DATA_DIR, 'invoices.db');

const AUTH_USER = 'rudra';
let AUTH_PASS = 'Rudra@3011';
const AUTH_TOKEN = 'rudra_auth_token_3011_sec';
const SETTINGS_PATH = path.join(DATA_DIR, 'settings.json');
if (fs.existsSync(SETTINGS_PATH)) {
  try {
    const s = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8'));
    if (s && s.password) AUTH_PASS = s.password;
  } catch (e) {}
}

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initialize SQLite Database
let db;
try {
  db = new DatabaseSync(DB_PATH);
  initDatabase(db);
  console.log(`[Database] SQLite database initialized at: ${DB_PATH}`);
} catch (err) {
  console.error('[Database Error] Failed to initialize SQLite database:', err);
  process.exit(1);
}

function initDatabase(database) {
  database.exec(`
    CREATE TABLE IF NOT EXISTS business_profile (
      id TEXT PRIMARY KEY,
      data TEXT NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS invoices (
      id TEXT PRIMARY KEY,
      invoice_number TEXT NOT NULL,
      client_name TEXT,
      date TEXT,
      due_date TEXT,
      amount REAL,
      amount_paid REAL DEFAULT 0,
      buying_cost REAL DEFAULT 0,
      status TEXT DEFAULT 'pending',
      business_name TEXT DEFAULT '',
      gst_enabled INTEGER,
      data TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);

  // Safe migration for existing databases
  const cols = database.prepare("PRAGMA table_info(invoices)").all().map(c => c.name);
  const newCols = [
    ['due_date', "TEXT DEFAULT ''"],
    ['amount_paid', 'REAL DEFAULT 0'],
    ['buying_cost', 'REAL DEFAULT 0'],
    ['status', "TEXT DEFAULT 'pending'"],
    ['business_name', "TEXT DEFAULT ''"]
  ];
  for (const [col, def] of newCols) {
    if (!cols.includes(col)) {
      database.exec(`ALTER TABLE invoices ADD COLUMN ${col} ${def}`);
    }
  }
}

// MIME Types for static files
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

// Helper to read JSON request body
function parseRequestBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 20 * 1024 * 1024) { // 20MB limit (e.g. logos)
        reject(new Error('Request entity too large'));
      }
    });
    req.on('end', () => {
      if (!body) {
        resolve({});
        return;
      }
      try {
        resolve(JSON.parse(body));
      } catch (err) {
        reject(new Error('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

// Helper to send JSON response
function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(data));
}

// Helper to serve static files
function serveStaticFile(req, res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Not Found');
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('500 Internal Server Error');
      }
      return;
    }
    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'no-cache'
    });
    res.end(content);
  });
}

// Create HTTP server
const server = http.createServer(async (req, res) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    res.end();
    return;
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // ==========================================
  // API ROUTES (/api/*)
  // ==========================================
  try {
    // 0. Auth routes
    if (pathname === '/api/login' && req.method === 'POST') {
      const body = await parseRequestBody(req);
      const u = String(body.username || '').trim();
      const p = String(body.password || '').trim();
      if (u === AUTH_USER && p === AUTH_PASS) {
        return sendJson(res, 200, {
          success: true,
          token: AUTH_TOKEN,
          username: AUTH_USER,
          message: 'Login successful'
        });
      }
      return sendJson(res, 401, {
        success: false,
        error: 'Invalid User ID or Password'
      });
    }

    if (pathname === '/api/auth-check' && req.method === 'GET') {
      const auth = req.headers.authorization || '';
      if (auth.startsWith('Bearer ') && auth.slice(7).trim() === AUTH_TOKEN) {
        return sendJson(res, 200, { authenticated: true, username: AUTH_USER });
      }
      return sendJson(res, 401, { authenticated: false, error: 'Unauthorized' });
    }

    // 1. Health check & status
    if (pathname === '/api/health' && req.method === 'GET') {
      return sendJson(res, 200, {
        status: 'ok',
        database: 'sqlite',
        databasePath: DB_PATH,
        serverTime: new Date().toISOString()
      });
    }

    // Require authentication for all data API endpoints
    const authHeader = req.headers.authorization || '';
    const isAuthenticated = authHeader.startsWith('Bearer ') && authHeader.slice(7).trim() === AUTH_TOKEN;
    if (!isAuthenticated) {
      return sendJson(res, 401, {
        error: 'Unauthorized. Access denied. Please sign in with User ID and Password.'
      });
    }

    // 2. Business profile
    if (pathname === '/api/profile') {
      if (req.method === 'GET') {
        const row = db.prepare('SELECT data FROM business_profile WHERE id = ?').get('default');
        const profile = row ? JSON.parse(row.data) : null;
        return sendJson(res, 200, { profile });
      }

      if (req.method === 'POST') {
        const body = await parseRequestBody(req);
        const profileData = JSON.stringify(body.profile || body);
        const stmt = db.prepare(`
          INSERT INTO business_profile (id, data, updated_at) 
          VALUES ('default', ?, CURRENT_TIMESTAMP)
          ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = CURRENT_TIMESTAMP
        `);
        stmt.run(profileData);
        return sendJson(res, 200, { success: true, message: 'Profile saved to database' });
      }
    }

    if (pathname === '/api/profiles') {
      if (req.method === 'GET') {
        const rows = db.prepare('SELECT id, data, updated_at FROM business_profile ORDER BY updated_at DESC').all();
        const profiles = (rows || []).map(r => {
          try {
            return { id: r.id, profile: JSON.parse(r.data), updatedAt: r.updated_at };
          } catch (e) {
            return null;
          }
        }).filter(Boolean);
        return sendJson(res, 200, { profiles });
      }

      if (req.method === 'POST') {
        const body = await parseRequestBody(req);
        const p = body.profile || body;
        const pId = String(body.id || p.id || p.name || 'default').trim();
        const profileData = JSON.stringify(p);
        const stmt = db.prepare(`
          INSERT INTO business_profile (id, data, updated_at) 
          VALUES (?, ?, CURRENT_TIMESTAMP)
          ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = CURRENT_TIMESTAMP
        `);
        stmt.run(pId, profileData);
        return sendJson(res, 200, { success: true, id: pId, message: 'Profile saved to database' });
      }
    }

    if (pathname.startsWith('/api/profiles/')) {
      if (req.method === 'DELETE') {
        const pId = decodeURIComponent(pathname.replace('/api/profiles/', ''));
        db.prepare('DELETE FROM business_profile WHERE id = ?').run(pId);
        return sendJson(res, 200, { success: true, message: 'Profile deleted from database' });
      }
    }

    if (pathname === '/api/profiles') {
      if (req.method === 'GET') {
        const rows = db.prepare('SELECT id, data, updated_at FROM business_profile ORDER BY updated_at DESC').all();
        const profiles = rows.map(r => {
          try {
            return { id: r.id, profile: JSON.parse(r.data), updatedAt: r.updated_at };
          } catch (e) {
            return null;
          }
        }).filter(Boolean);
        return sendJson(res, 200, { profiles });
      }

      if (req.method === 'POST') {
        const body = await parseRequestBody(req);
        const p = body.profile || body;
        const pId = String(body.id || p.id || p.name || 'default').trim();
        const profileData = JSON.stringify(p);
        const stmt = db.prepare(`
          INSERT INTO business_profile (id, data, updated_at) 
          VALUES (?, ?, CURRENT_TIMESTAMP)
          ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = CURRENT_TIMESTAMP
        `);
        stmt.run(pId, profileData);
        return sendJson(res, 200, { success: true, id: pId, message: 'Profile saved to database' });
      }
    }

    if (pathname.startsWith('/api/profiles/')) {
      const pId = decodeURIComponent(pathname.replace('/api/profiles/', ''));
      if (req.method === 'DELETE') {
        db.prepare('DELETE FROM business_profile WHERE id = ?').run(pId);
        return sendJson(res, 200, { success: true, message: 'Profile deleted from database' });
      }
    }

    // 3. Invoices List & Search
    if (pathname === '/api/invoices') {
      if (req.method === 'GET') {
        const search = parsedUrl.searchParams.get('search') || '';
        const today = new Date().toISOString().split('T')[0];
        let rows;
        if (search) {
          const query = `%${search}%`;
          rows = db.prepare(`
            SELECT id, invoice_number, client_name, date, due_date, amount, amount_paid, buying_cost, status, business_name, gst_enabled, data, created_at, updated_at
            FROM invoices
            WHERE invoice_number LIKE ? OR client_name LIKE ? OR business_name LIKE ?
            ORDER BY date DESC, created_at DESC
          `).all(query, query, query);
        } else {
          rows = db.prepare(`
            SELECT id, invoice_number, client_name, date, due_date, amount, amount_paid, buying_cost, status, business_name, gst_enabled, data, created_at, updated_at
            FROM invoices
            ORDER BY date DESC, created_at DESC
          `).all();
        }

        const invoices = rows.map(r => {
          let s = r.status || 'pending';
          const due = r.due_date || '';
          if (s === 'pending' && due && due < today) s = 'overdue';
          return {
            id: r.id,
            invoiceNumber: r.invoice_number,
            clientName: r.client_name,
            date: r.date,
            dueDate: due,
            amount: r.amount,
            amountPaid: r.amount_paid || 0,
            buyingCost: r.buying_cost || 0,
            status: s,
            businessName: r.business_name || '',
            gstEnabled: r.gst_enabled === 1,
            savedAt: r.updated_at,
            data: JSON.parse(r.data)
          };
        });

        return sendJson(res, 200, { count: invoices.length, invoices });
      }

      if (req.method === 'POST') {
        const body = await parseRequestBody(req);
        const record = body.invoice || body;

        const id = String(record.id || record.invoiceNumber || ('INV-' + Date.now())).trim();
        const invoiceNumber = String(record.invoiceNumber || id).trim();
        const clientName = String(record.clientName || 'Unnamed Client').trim();
        const date = String(record.date || new Date().toISOString().split('T')[0]);
        const dueDate = String(record.dueDate || '');
        const amount = Number(record.amount || 0);
        const amountPaid = Number(record.amountPaid || 0);
        const buyingCost = Number(record.buyingCost || 0);
        const status = String(record.status || 'pending');
        const businessName = String(record.businessName || '').trim();
        const gstEnabled = (record.gstEnabled !== false) ? 1 : 0;
        const dataJson = JSON.stringify(record.data || record);

        const stmt = db.prepare(`
          INSERT INTO invoices (id, invoice_number, client_name, date, due_date, amount, amount_paid, buying_cost, status, business_name, gst_enabled, data, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
          ON CONFLICT(id) DO UPDATE SET
            invoice_number = excluded.invoice_number,
            client_name = excluded.client_name,
            date = excluded.date,
            due_date = excluded.due_date,
            amount = excluded.amount,
            amount_paid = excluded.amount_paid,
            buying_cost = excluded.buying_cost,
            status = excluded.status,
            business_name = excluded.business_name,
            gst_enabled = excluded.gst_enabled,
            data = excluded.data,
            updated_at = CURRENT_TIMESTAMP
        `);
        stmt.run(id, invoiceNumber, clientName, date, dueDate, amount, amountPaid, buyingCost, status, businessName, gstEnabled, dataJson);

        return sendJson(res, 200, { success: true, id, message: `Invoice #${invoiceNumber} saved to database` });
      }
    }

    // Dashboard Analytics Endpoint
    if (pathname === '/api/dashboard' && req.method === 'GET') {
      const today = new Date().toISOString().split('T')[0];
      const pendingRows = db.prepare("SELECT id, due_date FROM invoices WHERE status = 'pending'").all();
      for (const r of pendingRows) {
        if (r.due_date && r.due_date < today) {
          db.prepare("UPDATE invoices SET status = 'overdue' WHERE id = ?").run(r.id);
        }
      }
      const byBiz = db.prepare("SELECT business_name, COUNT(*) as cnt, COALESCE(SUM(amount),0) as rev, COALESCE(SUM(amount_paid),0) as paid FROM invoices GROUP BY business_name").all();
      const allInv = db.prepare("SELECT id, invoice_number, client_name, date, due_date, amount, amount_paid, status, business_name FROM invoices ORDER BY date DESC").all();

      const totalRevenue = byBiz.reduce((s, r) => s + r.rev, 0);
      const totalPaid = byBiz.reduce((s, r) => s + r.paid, 0);
      const totalPending = totalRevenue - totalPaid;
      const paidCount = allInv.filter(r => r.status === 'paid').length;
      const pendingCount = allInv.filter(r => r.status === 'pending').length;
      const overdueCount = allInv.filter(r => r.status === 'overdue').length;

      return sendJson(res, 200, {
        totalRevenue,
        totalPaid,
        totalPending,
        paidCount,
        pendingCount,
        overdueCount,
        totalInvoices: allInv.length,
        businesses: byBiz.map(r => ({
          name: r.business_name || 'Untagged',
          invoiceCount: r.cnt,
          totalAmount: r.rev,
          totalPaid: r.paid,
          pending: r.rev - r.paid
        })),
        invoices: allInv.map(r => ({
          id: r.id,
          invoiceNumber: r.invoice_number,
          clientName: r.client_name,
          date: r.date,
          dueDate: r.due_date,
          amount: r.amount,
          amountPaid: r.amount_paid || 0,
          status: r.status || 'pending',
          businessName: r.business_name || ''
        }))
      });
    }

    // Change Password Endpoint
    if (pathname === '/api/change-password' && req.method === 'PATCH') {
      const body = await parseRequestBody(req);
      const current = String(body.currentPassword || '').trim();
      const newPass = String(body.newPassword || '').trim();
      if (current !== AUTH_PASS) {
        return sendJson(res, 401, { error: 'Current password is incorrect.' });
      }
      if (newPass.length < 6) {
        return sendJson(res, 400, { error: 'New password must be at least 6 characters.' });
      }
      AUTH_PASS = newPass;
      let settings = {};
      if (fs.existsSync(SETTINGS_PATH)) {
        try { settings = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8')); } catch (e) {}
      }
      settings.password = newPass;
      fs.writeFileSync(SETTINGS_PATH, JSON.stringify(settings));
      return sendJson(res, 200, { success: true, message: 'Password changed successfully.' });
    }

    // Update Invoice Status (/api/invoices/:id/status)
    if (pathname.startsWith('/api/invoices/') && pathname.endsWith('/status') && req.method === 'PATCH') {
      const invoiceId = decodeURIComponent(pathname.slice('/api/invoices/'.length, -'/status'.length));
      const body = await parseRequestBody(req);
      const newStatus = String(body.status || 'pending');
      if (body.amountPaid !== undefined && body.amountPaid !== null) {
        db.prepare("UPDATE invoices SET status = ?, amount_paid = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(newStatus, Number(body.amountPaid), invoiceId);
      } else {
        db.prepare("UPDATE invoices SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(newStatus, invoiceId);
      }
      return sendJson(res, 200, { success: true, id: invoiceId, status: newStatus });
    }

    // 4. Single Invoice operations (/api/invoices/:id)
    if (pathname.startsWith('/api/invoices/')) {
      const invoiceId = decodeURIComponent(pathname.substring('/api/invoices/'.length));

      if (req.method === 'GET') {
        const row = db.prepare('SELECT * FROM invoices WHERE id = ?').get(invoiceId);
        if (!row) {
          return sendJson(res, 404, { error: 'Invoice not found' });
        }
        return sendJson(res, 200, {
          invoice: {
            id: row.id,
            invoiceNumber: row.invoice_number,
            clientName: row.client_name,
            date: row.date,
            amount: row.amount,
            gstEnabled: row.gst_enabled === 1,
            savedAt: row.updated_at,
            data: JSON.parse(row.data)
          }
        });
      }

      if (req.method === 'DELETE') {
        const stmt = db.prepare('DELETE FROM invoices WHERE id = ?');
        stmt.run(invoiceId);
        return sendJson(res, 200, { success: true, message: `Invoice deleted from database` });
      }
    }

    // 5. Full Database Backup & Restore
    if (pathname === '/api/backup') {
      if (req.method === 'GET') {
        const profileRow = db.prepare('SELECT data FROM business_profile WHERE id = ?').get('default');
        const invoiceRows = db.prepare('SELECT * FROM invoices ORDER BY date DESC').all();

        const backupData = {
          version: '2.0',
          databaseType: 'sqlite',
          exportedAt: new Date().toISOString(),
          defaultProfile: profileRow ? JSON.parse(profileRow.data) : null,
          savedInvoices: invoiceRows.map(r => ({
            id: r.id,
            invoiceNumber: r.invoice_number,
            clientName: r.client_name,
            date: r.date,
            amount: r.amount,
            gstEnabled: r.gst_enabled === 1,
            savedAt: r.updated_at,
            data: JSON.parse(r.data)
          }))
        };
        return sendJson(res, 200, backupData);
      }

      if (req.method === 'POST') {
        const body = await parseRequestBody(req);

        // Restore profile
        if (body.defaultProfile) {
          const profileData = typeof body.defaultProfile === 'string'
            ? body.defaultProfile
            : JSON.stringify(body.defaultProfile);
          db.prepare(`
            INSERT INTO business_profile (id, data, updated_at) 
            VALUES ('default', ?, CURRENT_TIMESTAMP)
            ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = CURRENT_TIMESTAMP
          `).run(profileData);
        }

        // Restore invoices
        if (Array.isArray(body.savedInvoices)) {
          const stmt = db.prepare(`
            INSERT INTO invoices (id, invoice_number, client_name, date, amount, gst_enabled, data, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(id) DO UPDATE SET
              invoice_number = excluded.invoice_number,
              client_name = excluded.client_name,
              date = excluded.date,
              amount = excluded.amount,
              gst_enabled = excluded.gst_enabled,
              data = excluded.data,
              updated_at = CURRENT_TIMESTAMP
          `);

          for (const inv of body.savedInvoices) {
            const id = String(inv.id || inv.invoiceNumber || ('INV-' + Math.random())).trim();
            const invoiceNumber = String(inv.invoiceNumber || id).trim();
            const clientName = String(inv.clientName || 'Client').trim();
            const date = String(inv.date || '');
            const amount = Number(inv.amount || 0);
            const gstEnabled = (inv.gstEnabled !== false) ? 1 : 0;
            const dataJson = JSON.stringify(inv.data || inv);
            stmt.run(id, invoiceNumber, clientName, date, amount, gstEnabled, dataJson);
          }
        }

        return sendJson(res, 200, { success: true, message: 'Database backup restored successfully' });
      }
    }
  } catch (err) {
    console.error('[API Error]', err);
    return sendJson(res, 500, { error: err.message });
  }

  // ==========================================
  // STATIC FILE SERVING
  // ==========================================
  let reqPath = pathname;
  if (reqPath === '/' || reqPath === '') {
    reqPath = '/index.html';
  }

  const safePath = path.normalize(path.join(ROOT_DIR, reqPath));

  // Security check: ensure path is within ROOT_DIR
  if (!safePath.startsWith(ROOT_DIR)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('403 Forbidden');
    return;
  }

  serveStaticFile(req, res, safePath);
});

server.listen(PORT, () => {
  console.log('='.repeat(65));
  console.log('   GST INVOICE PRO - DATABASE SERVER STARTED');
  console.log('='.repeat(65));
  console.log(` > Application URL : http://localhost:${PORT}`);
  console.log(` > Database File   : ${DB_PATH}`);
  console.log(` > Database Engine : SQLite (Persistent, Multi-Device Ready)`);
  console.log('='.repeat(65));
});
