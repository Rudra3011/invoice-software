// ========================================================
// GST Invoice Pro - Database Server (Node.js & SQLite)
// Zero external dependencies required (Node 22+ built-in)
// ========================================================

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const PORT = process.env.PORT || 3000;
const ROOT_DIR = __dirname;
const DATA_DIR = path.join(ROOT_DIR, 'data');
const DB_PATH = path.join(DATA_DIR, 'invoices.db');

const AUTH_USER = 'rudra';
const AUTH_PASS = 'Rudra@3011';
const AUTH_TOKEN = 'rudra_auth_token_3011_sec';

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initialize SQLite Database
let db;
try {
  db = new DatabaseSync(DB_PATH);
  initDatabase(db);
  console.log(`[Database] SQLite database initialized at: ${DB_PATH}`);
} catch (err) {
  console.error('[Database Error] Failed to initialize SQLite database:', err);
  process.exit(1);
}

function initDatabase(database) {
  database.exec(`
    CREATE TABLE IF NOT EXISTS business_profile (
      id TEXT PRIMARY KEY,
      data TEXT NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS invoices (
      id TEXT PRIMARY KEY,
      invoice_number TEXT NOT NULL,
      client_name TEXT,
      date TEXT,
      amount REAL,
      gst_enabled INTEGER,
      data TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);
}

// MIME Types for static files
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

// Helper to read JSON request body
function parseRequestBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 20 * 1024 * 1024) { // 20MB limit (e.g. logos)
        reject(new Error('Request entity too large'));
      }
    });
    req.on('end', () => {
      if (!body) {
        resolve({});
        return;
      }
      try {
        resolve(JSON.parse(body));
      } catch (err) {
        reject(new Error('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

// Helper to send JSON response
function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(data));
}

// Helper to serve static files
function serveStaticFile(req, res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Not Found');
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('500 Internal Server Error');
      }
      return;
    }
    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'no-cache'
    });
    res.end(content);
  });
}

// Create HTTP server
const server = http.createServer(async (req, res) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    res.end();
    return;
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // ==========================================
  // API ROUTES (/api/*)
  // ==========================================
  try {
    // 0. Auth routes
    if (pathname === '/api/login' && req.method === 'POST') {
      const body = await parseRequestBody(req);
      const u = String(body.username || '').trim();
      const p = String(body.password || '').trim();
      if (u === AUTH_USER && p === AUTH_PASS) {
        return sendJson(res, 200, {
          success: true,
          token: AUTH_TOKEN,
          username: AUTH_USER,
          message: 'Login successful'
        });
      }
      return sendJson(res, 401, {
        success: false,
        error: 'Invalid User ID or Password'
      });
    }

    if (pathname === '/api/auth-check' && req.method === 'GET') {
      const auth = req.headers.authorization || '';
      if (auth.startsWith('Bearer ') && auth.slice(7).trim() === AUTH_TOKEN) {
        return sendJson(res, 200, { authenticated: true, username: AUTH_USER });
      }
      return sendJson(res, 401, { authenticated: false, error: 'Unauthorized' });
    }

    // 1. Health check & status
    if (pathname === '/api/health' && req.method === 'GET') {
      return sendJson(res, 200, {
        status: 'ok',
        database: 'sqlite',
        databasePath: DB_PATH,
        serverTime: new Date().toISOString()
      });
    }

    // Require authentication for all data API endpoints
    const authHeader = req.headers.authorization || '';
    const isAuthenticated = authHeader.startsWith('Bearer ') && authHeader.slice(7).trim() === AUTH_TOKEN;
    if (!isAuthenticated) {
      return sendJson(res, 401, {
        error: 'Unauthorized. Access denied. Please sign in with User ID and Password.'
      });
    }

    // 2. Business profile
    if (pathname === '/api/profile') {
      if (req.method === 'GET') {
        const row = db.prepare('SELECT data FROM business_profile WHERE id = ?').get('default');
        const profile = row ? JSON.parse(row.data) : null;
        return sendJson(res, 200, { profile });
      }

      if (req.method === 'POST') {
        const body = await parseRequestBody(req);
        const profileData = JSON.stringify(body.profile || body);
        const stmt = db.prepare(`
          INSERT INTO business_profile (id, data, updated_at) 
          VALUES ('default', ?, CURRENT_TIMESTAMP)
          ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = CURRENT_TIMESTAMP
        `);
        stmt.run(profileData);
        return sendJson(res, 200, { success: true, message: 'Profile saved to database' });
      }
    }

    if (pathname === '/api/profiles') {
      if (req.method === 'GET') {
        const rows = db.prepare('SELECT id, data, updated_at FROM business_profile ORDER BY updated_at DESC').all();
        const profiles = (rows || []).map(r => {
          try {
            return { id: r.id, profile: JSON.parse(r.data), updatedAt: r.updated_at };
          } catch (e) {
            return null;
          }
        }).filter(Boolean);
        return sendJson(res, 200, { profiles });
      }

      if (req.method === 'POST') {
        const body = await parseRequestBody(req);
        const p = body.profile || body;
        const pId = String(body.id || p.id || p.name || 'default').trim();
        const profileData = JSON.stringify(p);
        const stmt = db.prepare(`
          INSERT INTO business_profile (id, data, updated_at) 
          VALUES (?, ?, CURRENT_TIMESTAMP)
          ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = CURRENT_TIMESTAMP
        `);
        stmt.run(pId, profileData);
        return sendJson(res, 200, { success: true, id: pId, message: 'Profile saved to database' });
      }
    }

    if (pathname.startsWith('/api/profiles/')) {
      if (req.method === 'DELETE') {
        const pId = decodeURIComponent(pathname.replace('/api/profiles/', ''));
        db.prepare('DELETE FROM business_profile WHERE id = ?').run(pId);
        return sendJson(res, 200, { success: true, message: 'Profile deleted from database' });
      }
    }

    if (pathname === '/api/profiles') {
      if (req.method === 'GET') {
        const rows = db.prepare('SELECT id, data, updated_at FROM business_profile ORDER BY updated_at DESC').all();
        const profiles = rows.map(r => {
          try {
            return { id: r.id, profile: JSON.parse(r.data), updatedAt: r.updated_at };
          } catch (e) {
            return null;
          }
        }).filter(Boolean);
        return sendJson(res, 200, { profiles });
      }

      if (req.method === 'POST') {
        const body = await parseRequestBody(req);
        const p = body.profile || body;
        const pId = String(body.id || p.id || p.name || 'default').trim();
        const profileData = JSON.stringify(p);
        const stmt = db.prepare(`
          INSERT INTO business_profile (id, data, updated_at) 
          VALUES (?, ?, CURRENT_TIMESTAMP)
          ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = CURRENT_TIMESTAMP
        `);
        stmt.run(pId, profileData);
        return sendJson(res, 200, { success: true, id: pId, message: 'Profile saved to database' });
      }
    }

    if (pathname.startsWith('/api/profiles/')) {
      const pId = decodeURIComponent(pathname.replace('/api/profiles/', ''));
      if (req.method === 'DELETE') {
        db.prepare('DELETE FROM business_profile WHERE id = ?').run(pId);
        return sendJson(res, 200, { success: true, message: 'Profile deleted from database' });
      }
    }

    // 3. Invoices List & Search
    if (pathname === '/api/invoices') {
      if (req.method === 'GET') {
        const search = parsedUrl.searchParams.get('search') || '';
        let rows;
        if (search) {
          const query = `%${search}%`;
          rows = db.prepare(`
            SELECT id, invoice_number, client_name, date, amount, gst_enabled, data, created_at, updated_at
            FROM invoices
            WHERE invoice_number LIKE ? OR client_name LIKE ?
            ORDER BY date DESC, created_at DESC
          `).all(query, query);
        } else {
          rows = db.prepare(`
            SELECT id, invoice_number, client_name, date, amount, gst_enabled, data, created_at, updated_at
            FROM invoices
            ORDER BY date DESC, created_at DESC
          `).all();
        }

        const invoices = rows.map(r => ({
          id: r.id,
          invoiceNumber: r.invoice_number,
          clientName: r.client_name,
          date: r.date,
          amount: r.amount,
          gstEnabled: r.gst_enabled === 1,
          savedAt: r.updated_at,
          data: JSON.parse(r.data)
        }));

        return sendJson(res, 200, { count: invoices.length, invoices });
      }

      if (req.method === 'POST') {
        const body = await parseRequestBody(req);
        const record = body.invoice || body;

        const id = String(record.id || record.invoiceNumber || ('INV-' + Date.now())).trim();
        const invoiceNumber = String(record.invoiceNumber || id).trim();
        const clientName = String(record.clientName || 'Unnamed Client').trim();
        const date = String(record.date || new Date().toISOString().split('T')[0]);
        const amount = Number(record.amount || 0);
        const gstEnabled = (record.gstEnabled !== false) ? 1 : 0;
        const dataJson = JSON.stringify(record.data || record);

        const stmt = db.prepare(`
          INSERT INTO invoices (id, invoice_number, client_name, date, amount, gst_enabled, data, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
          ON CONFLICT(id) DO UPDATE SET
            invoice_number = excluded.invoice_number,
            client_name = excluded.client_name,
            date = excluded.date,
            amount = excluded.amount,
            gst_enabled = excluded.gst_enabled,
            data = excluded.data,
            updated_at = CURRENT_TIMESTAMP
        `);
        stmt.run(id, invoiceNumber, clientName, date, amount, gstEnabled, dataJson);

        return sendJson(res, 200, { success: true, id, message: `Invoice #${invoiceNumber} saved to database` });
      }
    }

    // 4. Single Invoice operations (/api/invoices/:id)
    if (pathname.startsWith('/api/invoices/')) {
      const invoiceId = decodeURIComponent(pathname.substring('/api/invoices/'.length));

      if (req.method === 'GET') {
        const row = db.prepare('SELECT * FROM invoices WHERE id = ?').get(invoiceId);
        if (!row) {
          return sendJson(res, 404, { error: 'Invoice not found' });
        }
        return sendJson(res, 200, {
          invoice: {
            id: row.id,
            invoiceNumber: row.invoice_number,
            clientName: row.client_name,
            date: row.date,
            amount: row.amount,
            gstEnabled: row.gst_enabled === 1,
            savedAt: row.updated_at,
            data: JSON.parse(row.data)
          }
        });
      }

      if (req.method === 'DELETE') {
        const stmt = db.prepare('DELETE FROM invoices WHERE id = ?');
        stmt.run(invoiceId);
        return sendJson(res, 200, { success: true, message: `Invoice deleted from database` });
      }
    }

    // 5. Full Database Backup & Restore
    if (pathname === '/api/backup') {
      if (req.method === 'GET') {
        const profileRow = db.prepare('SELECT data FROM business_profile WHERE id = ?').get('default');
        const invoiceRows = db.prepare('SELECT * FROM invoices ORDER BY date DESC').all();

        const backupData = {
          version: '2.0',
          databaseType: 'sqlite',
          exportedAt: new Date().toISOString(),
          defaultProfile: profileRow ? JSON.parse(profileRow.data) : null,
          savedInvoices: invoiceRows.map(r => ({
            id: r.id,
            invoiceNumber: r.invoice_number,
            clientName: r.client_name,
            date: r.date,
            amount: r.amount,
            gstEnabled: r.gst_enabled === 1,
            savedAt: r.updated_at,
            data: JSON.parse(r.data)
          }))
        };
        return sendJson(res, 200, backupData);
      }

      if (req.method === 'POST') {
        const body = await parseRequestBody(req);

        // Restore profile
        if (body.defaultProfile) {
          const profileData = typeof body.defaultProfile === 'string'
            ? body.defaultProfile
            : JSON.stringify(body.defaultProfile);
          db.prepare(`
            INSERT INTO business_profile (id, data, updated_at) 
            VALUES ('default', ?, CURRENT_TIMESTAMP)
            ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = CURRENT_TIMESTAMP
          `).run(profileData);
        }

        // Restore invoices
        if (Array.isArray(body.savedInvoices)) {
          const stmt = db.prepare(`
            INSERT INTO invoices (id, invoice_number, client_name, date, amount, gst_enabled, data, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(id) DO UPDATE SET
              invoice_number = excluded.invoice_number,
              client_name = excluded.client_name,
              date = excluded.date,
              amount = excluded.amount,
              gst_enabled = excluded.gst_enabled,
              data = excluded.data,
              updated_at = CURRENT_TIMESTAMP
          `);

          for (const inv of body.savedInvoices) {
            const id = String(inv.id || inv.invoiceNumber || ('INV-' + Math.random())).trim();
            const invoiceNumber = String(inv.invoiceNumber || id).trim();
            const clientName = String(inv.clientName || 'Client').trim();
            const date = String(inv.date || '');
            const amount = Number(inv.amount || 0);
            const gstEnabled = (inv.gstEnabled !== false) ? 1 : 0;
            const dataJson = JSON.stringify(inv.data || inv);
            stmt.run(id, invoiceNumber, clientName, date, amount, gstEnabled, dataJson);
          }
        }

        return sendJson(res, 200, { success: true, message: 'Database backup restored successfully' });
      }
    }
  } catch (err) {
    console.error('[API Error]', err);
    return sendJson(res, 500, { error: err.message });
  }

  // ==========================================
  // STATIC FILE SERVING
  // ==========================================
  let reqPath = pathname;
  if (reqPath === '/' || reqPath === '') {
    reqPath = '/index.html';
  }

  const safePath = path.normalize(path.join(ROOT_DIR, reqPath));

  // Security check: ensure path is within ROOT_DIR
  if (!safePath.startsWith(ROOT_DIR)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('403 Forbidden');
    return;
  }

  serveStaticFile(req, res, safePath);
});

server.listen(PORT, () => {
  console.log('='.repeat(65));
  console.log('   GST INVOICE PRO - DATABASE SERVER STARTED');
  console.log('='.repeat(65));
  console.log(` > Application URL : http://localhost:${PORT}`);
  console.log(` > Database File   : ${DB_PATH}`);
  console.log(` > Database Engine : SQLite (Persistent, Multi-Device Ready)`);
  console.log('='.repeat(65));
});
