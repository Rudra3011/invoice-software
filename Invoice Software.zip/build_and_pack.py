# -*- coding: utf-8 -*-
import os
import subprocess
import zipfile

# 1. Run build_protected.py
print("Running build_protected.py...")
res = subprocess.run(["python", "build_protected.py"], capture_output=True, text=True)
print(res.stdout)
if res.returncode != 0:
    print("Error building protected app.js:", res.stderr)
    exit(1)

# 2. Syntax check with node
print("Checking syntax with node...")
res2 = subprocess.run(["node", "-c", "js/app.js"], capture_output=True, text=True)
if res2.returncode != 0:
    print("Node syntax check failed on js/app.js:", res2.stderr)
    exit(1)
print("js/app.js syntax is VALID!")

# 3. Create zip with dual path structure
zip_name = "Invoice Software.zip"
file_list = [
    (".gitignore", ".gitignore"),
    ("index.html", "index.html"),
    ("package.json", "package.json"),
    ("README.md", "README.md"),
    ("run_server.py", "run_server.py"),
    ("server.js", "server.js"),
    ("start.bat", "start.bat"),
    ("start_python.bat", "start_python.bat"),
    ("build_protected.py", "build_protected.py"),
    (os.path.join("css", "print.css"), "css/print.css"),
    (os.path.join("css", "style.css"), "css/style.css"),
    (os.path.join("data", "invoices.db"), "data/invoices.db"),
    (os.path.join("js", "app.js"), "js/app.js"),
    (os.path.join("js", "app.src.js"), "js/app.src.js"),
    (os.path.join("js", "gst-states.js"), "js/gst-states.js"),
    (os.path.join("js", "number-to-words.js"), "js/number-to-words.js"),
    (os.path.join("js", "qrcode.js"), "js/qrcode.js"),
    (os.path.join("js", "templates.js"), "js/templates.js"),
]

with zipfile.ZipFile(zip_name, "w", zipfile.ZIP_DEFLATED) as z:
    for local_path, arc_path in file_list:
        if os.path.exists(local_path):
            # 1. Root level entry
            z.write(local_path, arc_path)
            # 2. Folder level entry inside "Invoice Software/"
            z.write(local_path, f"Invoice Software/{arc_path}")
            print(f"Added {arc_path} (root & Invoice Software/)")
        else:
            print(f"WARNING: File not found: {local_path}")

print(f"\n{zip_name} packaged successfully! Size: {os.path.getsize(zip_name)} bytes")
