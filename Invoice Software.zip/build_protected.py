import base64
import os
import re

src_path = os.path.join("js", "app.src.js")
dest_path = os.path.join("js", "app.js")

with open(src_path, "r", encoding="utf-8") as f:
    code = f.read()

# Strip single-line comments that are on their own lines
lines = code.split("\n")
cleaned_lines = []
for line in lines:
    stripped = line.strip()
    if stripped.startswith("//") and not stripped.startswith("//#"):
        continue
    cleaned_lines.append(line)

cleaned_code = "\n".join(cleaned_lines)

# Encode to base64
b64_payload = base64.b64encode(cleaned_code.encode("utf-8")).decode("ascii")

# Split payload into chunks for obfuscation
chunk_size = 120
chunks = [b64_payload[i:i + chunk_size] for i in range(0, len(b64_payload), chunk_size)]
chunks_js = ",\n  ".join(f'"{c}"' for c in chunks)

obfuscated_js = f"""/**
 * @license Protected Enterprise Application Module
 * Proprietary and Confidential - Unauthorized copying or decompilation prohibited.
 */
(function(_0x1a){{
  var _0x4e = [
  {chunks_js}
  ].join("");
  var _0x2c = decodeURIComponent(escape(atob(_0x4e)));
  (1, eval)(_0x2c);
}})(window);
"""

with open(dest_path, "w", encoding="utf-8") as f:
    f.write(obfuscated_js)

print("Obfuscated js/app.js written successfully! Size:", os.path.getsize(dest_path), "bytes")
