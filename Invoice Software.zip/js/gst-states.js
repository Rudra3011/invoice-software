// Indian States & Union Territories with GST State Codes
const GST_STATES = [
  { code: "01", name: "Jammu and Kashmir" },
  { code: "02", name: "Himachal Pradesh" },
  { code: "03", name: "Punjab" },
  { code: "04", name: "Chandigarh" },
  { code: "05", name: "Uttarakhand" },
  { code: "06", name: "Haryana" },
  { code: "07", name: "Delhi" },
  { code: "08", name: "Rajasthan" },
  { code: "09", name: "Uttar Pradesh" },
  { code: "10", name: "Bihar" },
  { code: "11", name: "Sikkim" },
  { code: "12", name: "Arunachal Pradesh" },
  { code: "13", name: "Nagaland" },
  { code: "14", name: "Manipur" },
  { code: "15", name: "Mizoram" },
  { code: "16", name: "Tripura" },
  { code: "17", name: "Meghalaya" },
  { code: "18", name: "Assam" },
  { code: "19", name: "West Bengal" },
  { code: "20", name: "Jharkhand" },
  { code: "21", name: "Odisha" },
  { code: "22", name: "Chhattisgarh" },
  { code: "23", name: "Madhya Pradesh" },
  { code: "24", name: "Gujarat" },
  { code: "26", name: "Dadra and Nagar Haveli and Daman and Diu" },
  { code: "27", name: "Maharashtra" },
  { code: "29", name: "Karnataka" },
  { code: "30", name: "Goa" },
  { code: "31", name: "Lakshadweep" },
  { code: "32", name: "Kerala" },
  { code: "33", name: "Tamil Nadu" },
  { code: "34", name: "Puducherry" },
  { code: "35", name: "Andaman and Nicobar Islands" },
  { code: "36", name: "Telangana" },
  { code: "37", name: "Andhra Pradesh" },
  { code: "38", name: "Ladakh" },
  { code: "97", name: "Other Territory" },
  { code: "99", name: "Centre Jurisdiction" }
];

function getStateByCode(code) {
  if (!code) return null;
  const normalized = String(code).padStart(2, "0");
  return GST_STATES.find(s => s.code === normalized) || null;
}

function extractStateCodeFromGSTIN(gstin) {
  if (!gstin || typeof gstin !== "string") return "";
  const cleaned = gstin.trim().toUpperCase();
  if (cleaned.length >= 2) {
    const code = cleaned.substring(0, 2);
    if (/^\d{2}$/.test(code) && getStateByCode(code)) {
      return code;
    }
  }
  return "";
}

function isIntraStateTransaction(supplierCode, recipientCode) {
  if (!supplierCode || !recipientCode) return true; // Default to intra-state if unspecified
  return String(supplierCode).padStart(2, "0") === String(recipientCode).padStart(2, "0");
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    GST_STATES,
    getStateByCode,
    extractStateCodeFromGSTIN,
    isIntraStateTransaction
  };
}
