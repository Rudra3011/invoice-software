// Indian Numbering System to Words Converter (Rupees & Paise)
function numberToWords(amount) {
  if (amount === null || amount === undefined || isNaN(amount)) return "Zero Rupees Only";
  
  const num = Math.abs(Number(amount));
  if (num === 0) return "Zero Rupees Only";

  const singleDigits = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"];
  const doubleDigits = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
  const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

  function convertTwoDigits(n) {
    if (n === 0) return "";
    if (n < 10) return singleDigits[n];
    if (n >= 10 && n < 20) return doubleDigits[n - 10];
    const ten = Math.floor(n / 10);
    const unit = n % 10;
    return tens[ten] + (unit !== 0 ? " " + singleDigits[unit] : "");
  }

  function convertThreeDigits(n) {
    let str = "";
    const hundred = Math.floor(n / 100);
    const rem = n % 100;
    if (hundred > 0) {
      str += singleDigits[hundred] + " Hundred";
    }
    if (rem > 0) {
      str += (str ? " " : "") + convertTwoDigits(rem);
    }
    return str.trim();
  }

  const integerPart = Math.floor(num);
  const decimalPart = Math.round((num - integerPart) * 100);

  let words = "";

  if (integerPart === 0) {
    words = "Zero";
  } else {
    // Break into Crores, Lakhs, Thousands, and remaining 3 digits
    let n = integerPart;
    const parts = [];

    // Remainder under 1000
    const rem1000 = n % 1000;
    n = Math.floor(n / 1000);

    // Thousands (under 100)
    const thousands = n % 100;
    n = Math.floor(n / 100);

    // Lakhs (under 100)
    const lakhs = n % 100;
    n = Math.floor(n / 100);

    // Crores
    const crores = n;

    if (crores > 0) {
      parts.push(numberToWordsIndianUnderCrore(crores) + " Crore");
    }
    if (lakhs > 0) {
      parts.push(convertTwoDigits(lakhs) + " Lakh");
    }
    if (thousands > 0) {
      parts.push(convertTwoDigits(thousands) + " Thousand");
    }
    if (rem1000 > 0) {
      parts.push(convertThreeDigits(rem1000));
    }

    words = parts.join(" ");
  }

  function numberToWordsIndianUnderCrore(val) {
    if (val < 100) return convertTwoDigits(val);
    const crRem1000 = val % 1000;
    let crRem = Math.floor(val / 1000);
    const crThousand = crRem % 100;
    crRem = Math.floor(crRem / 100);
    const crLakh = crRem % 100;

    const sub = [];
    if (crLakh > 0) sub.push(convertTwoDigits(crLakh) + " Lakh");
    if (crThousand > 0) sub.push(convertTwoDigits(crThousand) + " Thousand");
    if (crRem1000 > 0) sub.push(convertThreeDigits(crRem1000));
    return sub.join(" ");
  }

  let result = "Rupees " + words.trim();

  if (decimalPart > 0) {
    const paiseWords = convertTwoDigits(decimalPart);
    result += " and " + paiseWords + " Paise";
  }

  return result + " Only";
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { numberToWords };
}
