// Main Application Controller for Invoice Software (GST & Non-GST)
// Includes SQLite Database API Sync with Local Storage Fallback

(function() {
  'use strict';

  // ==========================================
  // API CLIENT (Connects to SQLite Backend)
  // ==========================================
  const ApiClient = {
    connected: false,
    baseUrl: '',
    databasePath: '',
    authToken: '',

    getAuthHeaders() {
      const headers = { 'Content-Type': 'application/json' };
      if (this.authToken) {
        headers['Authorization'] = `Bearer ${this.authToken}`;
      }
      return headers;
    },

    async login(username, password) {
      if (this.connected && this.baseUrl !== undefined) {
        try {
          const res = await fetch(`${this.baseUrl}/api/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
          });
          if (res.ok) {
            const data = await res.json();
            this.authToken = data.token || 'rudra_auth_token_3011_sec';
            return { success: true, token: this.authToken };
          }
          const errData = await res.json().catch(() => ({}));
          return { success: false, error: errData.error || 'Invalid User ID or Password' };
        } catch (e) {
          // If server fails or offline fallback
        }
      }

      // Offline / Static fallback validation
      if (username === 'rudra' && password === 'Rudra@3011') {
        this.authToken = 'rudra_auth_token_3011_sec';
        return { success: true, token: this.authToken };
      }
      return { success: false, error: 'Invalid User ID or Password' };
    },

    async checkHealth() {
      // Auto-detect server across potential hosts:
      // 1. Current origin (if loaded via http/https)
      // 2. http://localhost:3000
      // 3. http://127.0.0.1:3000
      // 4. http://localhost:8000
      // 5. http://127.0.0.1:8000
      const candidates = [];
      if (window.location.protocol === 'http:' || window.location.protocol === 'https:') {
        candidates.push('');
      }
      candidates.push('http://localhost:3000', 'http://127.0.0.1:3000', 'http://localhost:8000', 'http://127.0.0.1:8000');

      for (const base of candidates) {
        try {
          const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
          const timer = controller ? setTimeout(() => controller.abort(), 1200) : null;
          const res = await fetch(`${base}/api/health`, {
            cache: 'no-store',
            signal: controller ? controller.signal : undefined
          });
          if (timer) clearTimeout(timer);
          if (res.ok) {
            const data = await res.json();
            if (data && data.status === 'ok') {
              this.connected = true;
              this.baseUrl = base;
              this.databasePath = data.databasePath || 'data/invoices.db';
              return data;
            }
          }
        } catch (e) {
          // Probe next candidate
        }
      }
      this.connected = false;
      this.baseUrl = '';
      return null;
    },

    async getProfile() {
      if (!this.connected) return null;
      try {
        const res = await fetch(`${this.baseUrl}/api/profile`, { cache: 'no-store' });
        if (res.ok) {
          const json = await res.json();
          return json.profile;
        }
      } catch (e) {}
      return null;
    },

    async saveProfile(profile) {
      if (!this.connected) return false;
      try {
        const res = await fetch(`${this.baseUrl}/api/profile`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ profile })
        });
        return res.ok;
      } catch (e) {
        return false;
      }
    },

    async getInvoices(search = '') {
      if (!this.connected) return null;
      try {
        const path = search ? `/api/invoices?search=${encodeURIComponent(search)}` : '/api/invoices';
        const res = await fetch(`${this.baseUrl}${path}`, { cache: 'no-store' });
        if (res.ok) {
          const json = await res.json();
          return json.invoices;
        }
      } catch (e) {}
      return null;
    },

    async saveInvoice(record) {
      if (!this.connected) return false;
      try {
        const res = await fetch(`${this.baseUrl}/api/invoices`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ invoice: record })
        });
        return res.ok;
      } catch (e) {
        return false;
      }
    },

    async deleteInvoice(id) {
      if (!this.connected) return false;
      try {
        const res = await fetch(`${this.baseUrl}/api/invoices/${encodeURIComponent(id)}`, {
          method: 'DELETE'
        });
        return res.ok;
      } catch (e) {
        return false;
      }
    },

    async getBackup() {
      if (!this.connected) return null;
      try {
        const res = await fetch(`${this.baseUrl}/api/backup`, { cache: 'no-store' });
        if (res.ok) return await res.json();
      } catch (e) {}
      return null;
    },

    async restoreBackup(backupData) {
      if (!this.connected) return false;
      try {
        const res = await fetch(`${this.baseUrl}/api/backup`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(backupData)
        });
        return res.ok;
      } catch (e) {
        return false;
      }
    }
  };

  // Default state structure
  const DEFAULT_STATE = {
    gstEnabled: true, // Toggle for GST vs Non-GST invoices
    discountEnabled: false, // Optional discount per line item
    roundOff: {
      mode: 'auto', // 'auto', 'manual', 'none'
      type: 'subtract', // 'subtract' or 'add'
      manualValue: 0
    },
    business: {
      name: 'Acme Enterprises Pvt. Ltd.',
      gstin: '27AAPFU0939F1ZV',
      state: 'Maharashtra',
      stateCode: '27',
      pan: 'AAPFU0939F',
      phone: '+91 98765 43210',
      email: 'billing@acme-enterprises.com',
      address: 'Suite 402, Trade Tower, Bandra Kurla Complex\nMumbai, Maharashtra - 400051',
      bankName: 'HDFC Bank',
      accountNo: '50200012345678',
      ifsc: 'HDFC0000123',
      branch: 'BKC Mumbai',
      upiId: 'acmeenterprises@hdfcbank',
      logo: '',
      signature: ''
    },
    client: {
      name: 'Horizon Infotech Solutions',
      gstin: '27AAACH7409R1ZZ',
      state: 'Maharashtra',
      stateCode: '27',
      phone: '+91 98220 12345',
      email: 'accounts@horizoninfotech.in',
      address: 'Plot 45, MIDC Industrial Area, Phase 2\nPune, Maharashtra - 411018'
    },
    shipping: {
      enabled: false,
      name: '',
      address: '',
      state: ''
    },
    invoice: {
      title: 'TAX INVOICE',
      number: 'INV-2026-001',
      date: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0],
      poNumber: 'PO-HORIZON-981',
      placeOfSupply: 'Maharashtra',
      reverseCharge: 'No',
      vehicleNo: '',
      notes: 'Thank you for your business! Please quote invoice number when transferring funds.',
      terms: '1. Goods / services once delivered are not refundable.\n2. Payment terms: Net 15 days.\n3. Delayed payments incur interest @ 18% p.a.\n4. Subject to Mumbai jurisdiction only.'
    },
    items: [
      {
        id: 'item-1',
        description: 'Web Application Development & UI Design Service',
        hsn: '998314',
        quantity: 1,
        rate: 80000,
        discount: 0,
        gstRate: 18,
        taxable: 80000,
        total: 94400
      },
      {
        id: 'item-2',
        description: 'Cloud Server Infrastructure Setup & Security Audit',
        hsn: '998313',
        quantity: 2,
        rate: 22000,
        discount: 0,
        gstRate: 18,
        taxable: 44000,
        total: 51920
      }
    ],
    extraCharges: 0,
    taxTypeOverride: 'auto', // 'auto', 'intra', 'inter'
    ui: {
      template: 'modern',
      accentColor: '#1e40af',
      zoom: 100
    }
  };

  // Working state copy
  let state = JSON.parse(JSON.stringify(DEFAULT_STATE));

  // ==========================================
  // AUTHENTICATION MANAGER (Login / Logout Guard)
  // ==========================================
  const AuthManager = {
    isAuthenticated: false,
    sessionKey: 'gst_auth_session',

    init() {
      const userInp = document.getElementById('login-username');
      const passInp = document.getElementById('login-password');
      const rememberChk = document.getElementById('login-remember');
      const form = document.getElementById('login-form');
      const errBox = document.getElementById('login-error');
      const errText = document.getElementById('login-error-text');
      const toggleEye = document.getElementById('btn-toggle-password');
      const logoutBtn = document.getElementById('btn-logout');

      // Check existing session in localStorage or sessionStorage
      const stored = localStorage.getItem(this.sessionKey) || sessionStorage.getItem(this.sessionKey);
      if (stored) {
        try {
          const sess = JSON.parse(stored);
          if (sess && sess.token) {
            ApiClient.authToken = sess.token;
            this.setLoggedIn(true, false);
          } else {
            this.setLoggedIn(false, false);
          }
        } catch (e) {
          this.setLoggedIn(false, false);
        }
      } else {
        this.setLoggedIn(false, false);
      }

      // Password toggle eye icon
      if (toggleEye && passInp) {
        toggleEye.addEventListener('click', () => {
          const isPass = passInp.type === 'password';
          passInp.type = isPass ? 'text' : 'password';
          toggleEye.innerHTML = isPass
            ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>'
            : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
        });
      }

      // Login form submit handler
      if (form) {
        form.addEventListener('submit', async e => {
          e.preventDefault();
          const u = (userInp ? userInp.value : '').trim();
          const p = (passInp ? passInp.value : '').trim();
          const remember = rememberChk ? rememberChk.checked : true;

          const submitBtn = document.getElementById('btn-login-submit');
          if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span>Verifying...</span>';
          }

          const result = await ApiClient.login(u, p);

          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<span>Sign In</span> <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>';
          }

          if (result.success) {
            if (errBox) errBox.style.display = 'none';
            const sessObj = JSON.stringify({ token: result.token, username: u, loggedAt: new Date().toISOString() });
            if (remember) {
              localStorage.setItem(this.sessionKey, sessObj);
            } else {
              sessionStorage.setItem(this.sessionKey, sessObj);
            }
            this.setLoggedIn(true, true);
            showToast('Welcome, ' + u + '! Signed in successfully.', 'success');
            initDatabaseSync();
          } else {
            if (errBox) {
              errBox.style.display = 'flex';
              if (errText) errText.textContent = result.error || 'Invalid User ID or Password';
            }
            if (passInp) {
              passInp.value = '';
              passInp.focus();
            }
          }
        });
      }

      // Logout button in navbar
      if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
          if (confirm('Are you sure you want to sign out?')) {
            localStorage.removeItem(this.sessionKey);
            sessionStorage.removeItem(this.sessionKey);
            ApiClient.authToken = '';
            this.setLoggedIn(false, false);
            if (userInp) userInp.value = '';
            if (passInp) passInp.value = '';
            if (errBox) errBox.style.display = 'none';
            showToast('You have been signed out', 'info');
          }
        });
      }
    },

    setLoggedIn(isLoggedIn, animate = false) {
      this.isAuthenticated = isLoggedIn;
      const overlay = document.getElementById('login-overlay');
      if (!overlay) return;
      if (isLoggedIn) {
        overlay.classList.add('authenticated');
      } else {
        overlay.classList.remove('authenticated');
        const userInp = document.getElementById('login-username');
        if (userInp) setTimeout(() => userInp.focus(), 150);
      }
    }
  };

  // Initialize application
  async function init() {
    AuthManager.init();
    populateStateSelects();
    loadSavedSettings();
    bindFormInputs();
    bindTableEvents();
    bindToolbarEvents();
    bindModalEvents();
    recalculateAndRender();

    // Check & sync with Database backend
    await initDatabaseSync();
  }

  // Check database connection and sync profile
  async function initDatabaseSync(showToasts = false) {
    const dbBadge = document.getElementById('db-status-badge');
    if (dbBadge && !dbBadge.dataset.listenerAttached) {
      dbBadge.dataset.listenerAttached = 'true';
      dbBadge.style.cursor = 'pointer';
      dbBadge.addEventListener('click', async () => {
        showToast('Connecting to SQLite database...', 'info');
        await initDatabaseSync(true);
      });
    }

    if (dbBadge) {
      dbBadge.textContent = 'Checking DB...';
    }

    const health = await ApiClient.checkHealth();

    if (health) {
      if (dbBadge) {
        dbBadge.className = 'badge-db connected';
        dbBadge.textContent = '● Database: SQLite Connected';
        dbBadge.title = `Connected to SQLite (${health.databasePath}). Click to re-check.`;
      }

      // Sync default profile from SQLite if present
      try {
        const dbProfile = await ApiClient.getProfile();
        if (dbProfile) {
          state.business = dbProfile;
          populateFormFromState();
          recalculateAndRender();
        }
      } catch (e) {}

      await updateHistoryBadge();
      if (showToasts) {
        showToast('Successfully connected to SQLite Database!', 'success');
      }
    } else {
      if (dbBadge) {
        dbBadge.className = 'badge-db offline';
        dbBadge.textContent = '● Offline (Click to Connect)';
        dbBadge.title = 'Database not connected. Double-click start_python.bat or start.bat, then click here.';
      }
      updateHistoryBadge();
      if (showToasts) {
        showToast('Database server not detected. Please run start_python.bat!', 'warning');
      }
    }
  }

  // Populate state dropdowns from GST_STATES
  function populateStateSelects() {
    const selects = ['business-state', 'client-state', 'invoice-pos', 'shipping-state'];
    selects.forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      el.innerHTML = '<option value="">-- Select State --</option>';
      GST_STATES.forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.name;
        opt.textContent = `${s.code} - ${s.name}`;
        opt.setAttribute('data-code', s.code);
        el.appendChild(opt);
      });
    });
  }

  // Load saved default profile and last draft if available
  function loadSavedSettings() {
    try {
      const savedProfile = localStorage.getItem('gst_inv_default_profile');
      if (savedProfile) {
        state.business = JSON.parse(savedProfile);
      }
      const savedDraft = localStorage.getItem('gst_inv_current_draft');
      if (savedDraft) {
        state = JSON.parse(savedDraft);
        if (state.gstEnabled === undefined) state.gstEnabled = true;
        if (state.discountEnabled === undefined) state.discountEnabled = false;
        if (!state.roundOff) {
          state.roundOff = { mode: 'auto', type: 'subtract', manualValue: 0 };
        }
      }
    } catch (e) {
      console.warn('Error loading localStorage:', e);
    }
  }

  // Save current draft automatically
  function autoSaveDraft() {
    try {
      localStorage.setItem('gst_inv_current_draft', JSON.stringify(state));
    } catch (e) {
      console.warn('Could not auto-save draft:', e);
    }
  }

  // Recalculate all totals, taxes and render the invoice sheet
  function recalculateAndRender() {
    const isGST = state.gstEnabled !== false;
    const hasDiscount = state.discountEnabled === true;

    // 1. Determine Intra-State vs Inter-State (only relevant for GST)
    let isIntra = true;
    if (isGST) {
      const busCode = state.business.stateCode;
      const clientCode = state.client.stateCode;
      const pos = state.invoice.placeOfSupply;

      if (state.taxTypeOverride === 'intra') {
        isIntra = true;
      } else if (state.taxTypeOverride === 'inter') {
        isIntra = false;
      } else {
        if (busCode && clientCode) {
          isIntra = String(busCode).padStart(2, '0') === String(clientCode).padStart(2, '0');
        } else if (state.business.state && pos) {
          isIntra = state.business.state.toLowerCase() === pos.toLowerCase();
        }
      }
    }

    // 2. Calculate row totals and group by HSN
    let totalTaxable = 0;
    let totalCGST = 0;
    let totalSGST = 0;
    let totalIGST = 0;
    const hsnMap = {};

    state.items.forEach(item => {
      const qty = Number(item.quantity) || 0;
      const rate = Number(item.rate) || 0;
      const discount = hasDiscount ? (Number(item.discount) || 0) : 0;
      const gstRate = isGST ? (Number(item.gstRate) || 0) : 0;

      const taxable = Math.max(0, (qty * rate) - discount);
      item.taxable = taxable;

      let cgstAmt = 0;
      let sgstAmt = 0;
      let igstAmt = 0;
      let taxAmt = 0;

      if (isGST && gstRate > 0 && taxable > 0) {
        taxAmt = (taxable * gstRate) / 100;
        if (isIntra) {
          cgstAmt = taxAmt / 2;
          sgstAmt = taxAmt / 2;
          totalCGST += cgstAmt;
          totalSGST += sgstAmt;
        } else {
          igstAmt = taxAmt;
          totalIGST += igstAmt;
        }
      }

      item.total = taxable + taxAmt;
      totalTaxable += taxable;

      // Group by HSN (GST mode only)
      if (isGST) {
        const hsnKey = (item.hsn || 'GEN') + '_' + gstRate;
        if (!hsnMap[hsnKey]) {
          hsnMap[hsnKey] = {
            hsn: item.hsn || 'General',
            taxable: 0,
            gstRate: gstRate,
            cgstRate: isIntra ? gstRate / 2 : 0,
            cgstAmount: 0,
            sgstRate: isIntra ? gstRate / 2 : 0,
            sgstAmount: 0,
            igstRate: isIntra ? 0 : gstRate,
            igstAmount: 0,
            totalTax: 0
          };
        }
        hsnMap[hsnKey].taxable += taxable;
        hsnMap[hsnKey].cgstAmount += cgstAmt;
        hsnMap[hsnKey].sgstAmount += sgstAmt;
        hsnMap[hsnKey].igstAmount += igstAmt;
        hsnMap[hsnKey].totalTax += taxAmt;
      }
    });

    const extraCharges = Number(state.extraCharges) || 0;
    const totalTax = isGST ? (totalCGST + totalSGST + totalIGST) : 0;
    const rawGrandTotal = totalTaxable + totalTax + extraCharges;

    // Round-off options (Auto, Manual, None)
    let roundOff = 0;
    let grandTotal = rawGrandTotal;

    const roundMode = (state.roundOff && state.roundOff.mode) || 'auto';
    if (roundMode === 'auto') {
      grandTotal = Math.round(rawGrandTotal);
      roundOff = grandTotal - rawGrandTotal;
    } else if (roundMode === 'manual') {
      const val = Number(state.roundOff.manualValue) || 0;
      if (state.roundOff.type === 'add') {
        roundOff = val;
        grandTotal = rawGrandTotal + val;
      } else {
        roundOff = -val;
        grandTotal = Math.max(0, rawGrandTotal - val);
      }
    } else {
      // 'none'
      roundOff = 0;
      grandTotal = rawGrandTotal;
    }

    const amountInWords = numberToWords(grandTotal);

    // Save calculations object to state
    state.calculations = {
      isIntraState: isIntra,
      totalTaxable: totalTaxable,
      totalCGST: totalCGST,
      totalSGST: totalSGST,
      totalIGST: totalIGST,
      totalTax: totalTax,
      extraCharges: extraCharges,
      roundOff: roundOff,
      grandTotal: grandTotal,
      amountInWords: amountInWords,
      hsnSummary: isGST ? Object.values(hsnMap) : []
    };

    // Update UI summary cards & badges
    updateEditorSummaryUI();

    // Render invoice sheet preview
    const sheetEl = document.getElementById('invoice-sheet');
    if (sheetEl && typeof InvoiceTemplates !== 'undefined') {
      sheetEl.innerHTML = InvoiceTemplates.render(state, state.ui.template, state.ui.accentColor);
    }

    autoSaveDraft();
  }

  // Update numbers in the left form summary box & GST/Non-GST UI states
  function updateEditorSummaryUI() {
    const calc = state.calculations;
    const fmt = InvoiceTemplates.formatCurrency;
    const isGST = state.gstEnabled !== false;
    const hasDiscount = state.discountEnabled === true;

    const sumTaxable = document.getElementById('sum-taxable');
    const sumCgstRow = document.getElementById('sum-cgst-row');
    const sumSgstRow = document.getElementById('sum-sgst-row');
    const sumIgstRow = document.getElementById('sum-igst-row');
    const sumCgst = document.getElementById('sum-cgst');
    const sumSgst = document.getElementById('sum-sgst');
    const sumIgst = document.getElementById('sum-igst');
    const sumTotal = document.getElementById('sum-grand-total');
    const taxTypeBadge = document.getElementById('badge-tax-type');
    const invoiceModeBadge = document.getElementById('badge-invoice-mode');
    const labelSubtotal = document.getElementById('label-subtotal');
    const groupTaxMode = document.getElementById('group-tax-mode');
    const groupTaxDisabledMsg = document.getElementById('group-tax-disabled-msg');
    const btnModeGst = document.getElementById('btn-mode-gst');
    const btnModeNonGst = document.getElementById('btn-mode-nongst');

    // Round Off UI elements
    const manualRoundoffGroup = document.getElementById('manual-roundoff-group');
    const autoRoundoffDisplay = document.getElementById('auto-roundoff-display');
    const sumRoundoff = document.getElementById('sum-roundoff');
    const sumRoundoffManual = document.getElementById('sum-roundoff-manual');

    if (sumTaxable) sumTaxable.textContent = fmt(calc.totalTaxable);

    // Mode Buttons active state
    if (btnModeGst && btnModeNonGst) {
      if (isGST) {
        btnModeGst.classList.add('active');
        btnModeNonGst.classList.remove('active');
      } else {
        btnModeGst.classList.remove('active');
        btnModeNonGst.classList.add('active');
      }
    }

    // Invoice mode badge
    if (invoiceModeBadge) {
      if (isGST) {
        invoiceModeBadge.textContent = 'GST Tax Invoice';
        invoiceModeBadge.className = 'badge-gst';
      } else {
        invoiceModeBadge.textContent = 'Non-GST Invoice';
        invoiceModeBadge.className = 'badge-nongst';
      }
    }

    // Subtotal label
    if (labelSubtotal) {
      labelSubtotal.textContent = isGST ? 'Taxable Subtotal:' : 'Subtotal:';
    }

    // Tax rows in summary card
    if (isGST) {
      if (groupTaxMode) groupTaxMode.style.display = 'block';
      if (groupTaxDisabledMsg) groupTaxDisabledMsg.style.display = 'none';

      if (calc.isIntraState) {
        if (sumCgstRow) sumCgstRow.style.display = 'flex';
        if (sumSgstRow) sumSgstRow.style.display = 'flex';
        if (sumIgstRow) sumIgstRow.style.display = 'none';
        if (sumCgst) sumCgst.textContent = '+ ' + fmt(calc.totalCGST);
        if (sumSgst) sumSgst.textContent = '+ ' + fmt(calc.totalSGST);
        if (taxTypeBadge) {
          taxTypeBadge.textContent = 'Intra-State (CGST + SGST)';
          taxTypeBadge.className = 'badge-gst';
        }
      } else {
        if (sumCgstRow) sumCgstRow.style.display = 'none';
        if (sumSgstRow) sumSgstRow.style.display = 'none';
        if (sumIgstRow) sumIgstRow.style.display = 'flex';
        if (sumIgst) sumIgst.textContent = '+ ' + fmt(calc.totalIGST);
        if (taxTypeBadge) {
          taxTypeBadge.textContent = 'Inter-State (IGST)';
          taxTypeBadge.className = 'badge-gst';
        }
      }
    } else {
      // Non-GST mode: hide tax rows completely
      if (sumCgstRow) sumCgstRow.style.display = 'none';
      if (sumSgstRow) sumSgstRow.style.display = 'none';
      if (sumIgstRow) sumIgstRow.style.display = 'none';
      if (groupTaxMode) groupTaxMode.style.display = 'none';
      if (groupTaxDisabledMsg) groupTaxDisabledMsg.style.display = 'block';

      if (taxTypeBadge) {
        taxTypeBadge.textContent = 'Non-GST (Tax Exempt)';
        taxTypeBadge.className = 'badge-nongst';
      }
    }

    // Round Off display logic
    const roundMode = (state.roundOff && state.roundOff.mode) || 'auto';
    if (roundMode === 'manual') {
      if (manualRoundoffGroup) manualRoundoffGroup.style.display = 'flex';
      if (autoRoundoffDisplay) autoRoundoffDisplay.style.display = 'none';
      if (sumRoundoffManual) {
        sumRoundoffManual.textContent = (calc.roundOff >= 0 ? '+' : '') + calc.roundOff.toFixed(2);
      }
    } else if (roundMode === 'none') {
      if (manualRoundoffGroup) manualRoundoffGroup.style.display = 'none';
      if (autoRoundoffDisplay) autoRoundoffDisplay.style.display = 'none';
    } else {
      // auto
      if (manualRoundoffGroup) manualRoundoffGroup.style.display = 'none';
      if (autoRoundoffDisplay) autoRoundoffDisplay.style.display = 'flex';
      if (sumRoundoff) {
        sumRoundoff.textContent = (calc.roundOff >= 0 ? '+' : '') + calc.roundOff.toFixed(2);
      }
    }

    // Toggle GST table header cells visibility
    document.querySelectorAll('.col-gst-field').forEach(el => {
      el.style.display = isGST ? '' : 'none';
    });

    // Toggle Discount table header cells visibility
    document.querySelectorAll('.col-disc-field').forEach(el => {
      el.style.display = hasDiscount ? '' : 'none';
    });

    if (sumTotal) sumTotal.textContent = fmt(calc.grandTotal);
  }

  // Populate form input elements from current state
  function populateFormFromState() {
    // Mode & Title
    const titleSelect = document.getElementById('invoice-title-select');
    const customTitleInput = document.getElementById('invoice-custom-title');
    const currentTitle = state.invoice.title || (state.gstEnabled ? 'TAX INVOICE' : 'INVOICE');

    if (titleSelect) {
      const knownTitles = ['TAX INVOICE', 'INVOICE', 'BILL OF SUPPLY', 'PROFORMA INVOICE', 'COMMERCIAL INVOICE'];
      if (knownTitles.includes(currentTitle)) {
        titleSelect.value = currentTitle;
        if (customTitleInput) customTitleInput.style.display = 'none';
      } else {
        titleSelect.value = 'CUSTOM';
        if (customTitleInput) {
          customTitleInput.style.display = 'inline-block';
          customTitleInput.value = currentTitle;
        }
      }
    }

    // Discount Toggle
    const discCheck = document.getElementById('discount-enable');
    if (discCheck) discCheck.checked = !!state.discountEnabled;

    // Round Off Mode
    const roundModeSelect = document.getElementById('roundoff-mode');
    if (roundModeSelect && state.roundOff) roundModeSelect.value = state.roundOff.mode || 'auto';

    const manualTypeSelect = document.getElementById('manual-roundoff-type');
    if (manualTypeSelect && state.roundOff) manualTypeSelect.value = state.roundOff.type || 'subtract';

    const manualValInput = document.getElementById('manual-roundoff-val');
    if (manualValInput && state.roundOff) {
      manualValInput.value = state.roundOff.manualValue || '';
    }

    // Business
    setVal('business-name', state.business.name);
    setVal('business-gstin', state.business.gstin);
    setVal('business-state', state.business.state);
    setVal('business-pan', state.business.pan);
    setVal('business-phone', state.business.phone);
    setVal('business-email', state.business.email);
    setVal('business-address', state.business.address);
    setVal('bank-name', state.business.bankName);
    setVal('bank-account', state.business.accountNo);
    setVal('bank-ifsc', state.business.ifsc);
    setVal('bank-branch', state.business.branch);
    setVal('bank-upi', state.business.upiId);

    // Client
    setVal('client-name', state.client.name);
    setVal('client-gstin', state.client.gstin);
    setVal('client-state', state.client.state);
    setVal('client-phone', state.client.phone);
    setVal('client-email', state.client.email);
    setVal('client-address', state.client.address);

    // Shipping
    const shipCheck = document.getElementById('ship-enable');
    if (shipCheck) shipCheck.checked = !!state.shipping.enabled;
    const shipSection = document.getElementById('shipping-details-section');
    if (shipSection) shipSection.style.display = state.shipping.enabled ? 'block' : 'none';
    setVal('shipping-name', state.shipping.name);
    setVal('shipping-address', state.shipping.address);
    setVal('shipping-state', state.shipping.state);

    // Invoice
    setVal('invoice-number', state.invoice.number);
    setVal('invoice-date', state.invoice.date);
    setVal('invoice-due-date', state.invoice.dueDate);
    setVal('invoice-po', state.invoice.poNumber);
    setVal('invoice-pos', state.invoice.placeOfSupply);
    setVal('invoice-reverse-charge', state.invoice.reverseCharge);
    setVal('invoice-vehicle', state.invoice.vehicleNo);
    setVal('invoice-notes', state.invoice.notes);
    setVal('invoice-terms', state.invoice.terms);
    setVal('extra-charges', state.extraCharges || 0);

    // Logos / Signatures
    updateImagePreview('logo-preview', state.business.logo);
    updateImagePreview('signature-preview', state.business.signature);

    // Render table rows
    renderItemsTableRows();
  }

  function setVal(id, val) {
    const el = document.getElementById(id);
    if (el) el.value = val || '';
  }

  function updateImagePreview(previewId, dataUrl) {
    const el = document.getElementById(previewId);
    if (!el) return;
    if (dataUrl) {
      el.innerHTML = `<img src="${dataUrl}" alt="Preview" style="max-width:100%; max-height:100%; object-fit:contain;">`;
    } else {
      el.innerHTML = '<span class="placeholder-icon">📷</span>';
    }
  }

  // Render items table rows in the editor
  function renderItemsTableRows() {
    const tbody = document.getElementById('items-tbody');
    if (!tbody) return;
    tbody.innerHTML = '';
    const isGST = state.gstEnabled !== false;
    const hasDiscount = state.discountEnabled === true;

    state.items.forEach((item, index) => {
      const tr = document.createElement('tr');
      tr.setAttribute('data-id', item.id);
      tr.innerHTML = `
        <td style="text-align: center; font-weight: 600; color: #64748b;">${index + 1}</td>
        <td>
          <input type="text" class="form-control item-desc" value="${escapeHtml(item.description)}" placeholder="Description of goods/service">
        </td>
        <td class="col-gst-field col-hsn" style="width: 75px; ${isGST ? '' : 'display: none;'}">
          <input type="text" class="form-control item-hsn" value="${escapeHtml(item.hsn)}" placeholder="HSN/SAC">
        </td>
        <td style="width: 60px;">
          <input type="number" class="form-control item-qty" value="${item.quantity}" min="0" step="any">
        </td>
        <td style="width: 85px;">
          <input type="number" class="form-control item-rate" value="${item.rate}" min="0" step="0.01">
        </td>
        <td class="col-disc-field" style="width: 65px; ${hasDiscount ? '' : 'display: none;'}">
          <input type="number" class="form-control item-disc" value="${item.discount || 0}" min="0" step="0.01">
        </td>
        <td class="col-gst-field col-gst" style="width: 75px; ${isGST ? '' : 'display: none;'}">
          <select class="form-control item-gst">
            <option value="0" ${item.gstRate === 0 ? 'selected' : ''}>0%</option>
            <option value="5" ${item.gstRate === 5 ? 'selected' : ''}>5%</option>
            <option value="12" ${item.gstRate === 12 ? 'selected' : ''}>12%</option>
            <option value="18" ${item.gstRate === 18 ? 'selected' : ''}>18%</option>
            <option value="28" ${item.gstRate === 28 ? 'selected' : ''}>28%</option>
          </select>
        </td>
        <td style="text-align: right; font-weight: 700; color: #0f172a; width: 90px;">
          ₹${(item.total || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
        </td>
        <td style="text-align: center; width: 35px;">
          <button class="btn-remove-row" title="Delete Row" data-index="${index}">✕</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    // Toggle header columns
    document.querySelectorAll('.col-gst-field').forEach(el => {
      el.style.display = isGST ? '' : 'none';
    });
    document.querySelectorAll('.col-disc-field').forEach(el => {
      el.style.display = hasDiscount ? '' : 'none';
    });
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/"/g, '&quot;');
  }

  // Bind all input event listeners
  function bindFormInputs() {
    populateFormFromState();

    // Helper for two-way binding
    function bindInput(id, updateFn) {
      const el = document.getElementById(id);
      if (!el) return;
      el.addEventListener('input', e => {
        updateFn(e.target.value);
        recalculateAndRender();
      });
      el.addEventListener('change', e => {
        updateFn(e.target.value);
        recalculateAndRender();
      });
    }

    // Mode Toggle Buttons (GST vs Non-GST)
    const btnModeGst = document.getElementById('btn-mode-gst');
    const btnModeNonGst = document.getElementById('btn-mode-nongst');
    const titleSelect = document.getElementById('invoice-title-select');
    const customTitleInput = document.getElementById('invoice-custom-title');

    if (btnModeGst) {
      btnModeGst.addEventListener('click', () => {
        state.gstEnabled = true;
        state.invoice.title = 'TAX INVOICE';
        if (titleSelect) titleSelect.value = 'TAX INVOICE';
        if (customTitleInput) customTitleInput.style.display = 'none';
        renderItemsTableRows();
        recalculateAndRender();
        showToast('Switched to GST Tax Invoice mode', 'info');
      });
    }

    if (btnModeNonGst) {
      btnModeNonGst.addEventListener('click', () => {
        state.gstEnabled = false;
        state.invoice.title = 'INVOICE';
        if (titleSelect) titleSelect.value = 'INVOICE';
        if (customTitleInput) customTitleInput.style.display = 'none';
        renderItemsTableRows();
        recalculateAndRender();
        showToast('Switched to Non-GST Invoice mode (0% tax)', 'info');
      });
    }

    // Discount Toggle
    const discCheck = document.getElementById('discount-enable');
    if (discCheck) {
      discCheck.addEventListener('change', e => {
        state.discountEnabled = e.target.checked;
        renderItemsTableRows();
        recalculateAndRender();
        showToast(state.discountEnabled ? 'Discount column enabled' : 'Discount column hidden', 'info');
      });
    }

    // Round Off Controls
    const roundModeSelect = document.getElementById('roundoff-mode');
    if (roundModeSelect) {
      roundModeSelect.addEventListener('change', e => {
        if (!state.roundOff) state.roundOff = {};
        state.roundOff.mode = e.target.value;
        recalculateAndRender();
      });
    }

    const manualRoundoffTypeSelect = document.getElementById('manual-roundoff-type');
    if (manualRoundoffTypeSelect) {
      manualRoundoffTypeSelect.addEventListener('change', e => {
        if (!state.roundOff) state.roundOff = {};
        state.roundOff.type = e.target.value;
        recalculateAndRender();
      });
    }

    const manualRoundoffValInput = document.getElementById('manual-roundoff-val');
    if (manualRoundoffValInput) {
      manualRoundoffValInput.addEventListener('input', e => {
        if (!state.roundOff) state.roundOff = {};
        state.roundOff.manualValue = parseFloat(e.target.value) || 0;
        recalculateAndRender();
      });
    }

    // Title Select & Custom Title
    if (titleSelect) {
      titleSelect.addEventListener('change', e => {
        const val = e.target.value;
        if (val === 'CUSTOM') {
          if (customTitleInput) {
            customTitleInput.style.display = 'inline-block';
            customTitleInput.focus();
            state.invoice.title = customTitleInput.value || 'INVOICE';
          }
        } else {
          if (customTitleInput) customTitleInput.style.display = 'none';
          state.invoice.title = val;
        }
        recalculateAndRender();
      });
    }

    if (customTitleInput) {
      customTitleInput.addEventListener('input', e => {
        state.invoice.title = e.target.value || 'INVOICE';
        recalculateAndRender();
      });
    }

    // Business details
    bindInput('business-name', v => { state.business.name = v; });
    bindInput('business-gstin', v => {
      state.business.gstin = v.toUpperCase();
      const code = extractStateCodeFromGSTIN(v);
      if (code) {
        const s = getStateByCode(code);
        if (s) {
          state.business.state = s.name;
          state.business.stateCode = s.code;
          setVal('business-state', s.name);
        }
      }
    });
    bindInput('business-state', v => {
      state.business.state = v;
      const s = GST_STATES.find(x => x.name === v);
      state.business.stateCode = s ? s.code : '';
    });
    bindInput('business-pan', v => { state.business.pan = v.toUpperCase(); });
    bindInput('business-phone', v => { state.business.phone = v; });
    bindInput('business-email', v => { state.business.email = v; });
    bindInput('business-address', v => { state.business.address = v; });

    // Bank details
    bindInput('bank-name', v => { state.business.bankName = v; });
    bindInput('bank-account', v => { state.business.accountNo = v; });
    bindInput('bank-ifsc', v => { state.business.ifsc = v.toUpperCase(); });
    bindInput('bank-branch', v => { state.business.branch = v; });
    bindInput('bank-upi', v => { state.business.upiId = v.trim(); });

    // Client details
    bindInput('client-name', v => { state.client.name = v; });
    bindInput('client-gstin', v => {
      state.client.gstin = v.toUpperCase();
      const code = extractStateCodeFromGSTIN(v);
      if (code) {
        const s = getStateByCode(code);
        if (s) {
          state.client.state = s.name;
          state.client.stateCode = s.code;
          setVal('client-state', s.name);
          if (!state.invoice.placeOfSupply) {
            state.invoice.placeOfSupply = s.name;
            setVal('invoice-pos', s.name);
          }
        }
      }
    });
    bindInput('client-state', v => {
      state.client.state = v;
      const s = GST_STATES.find(x => x.name === v);
      state.client.stateCode = s ? s.code : '';
      if (!state.invoice.placeOfSupply) {
        state.invoice.placeOfSupply = v;
        setVal('invoice-pos', v);
      }
    });
    bindInput('client-phone', v => { state.client.phone = v; });
    bindInput('client-email', v => { state.client.email = v; });
    bindInput('client-address', v => { state.client.address = v; });

    // Shipping details
    const shipCheck = document.getElementById('ship-enable');
    if (shipCheck) {
      shipCheck.addEventListener('change', e => {
        state.shipping.enabled = e.target.checked;
        const sSec = document.getElementById('shipping-details-section');
        if (sSec) sSec.style.display = state.shipping.enabled ? 'block' : 'none';
        recalculateAndRender();
      });
    }
    bindInput('shipping-name', v => { state.shipping.name = v; });
    bindInput('shipping-address', v => { state.shipping.address = v; });
    bindInput('shipping-state', v => { state.shipping.state = v; });

    // Invoice Meta
    bindInput('invoice-number', v => { state.invoice.number = v; });
    bindInput('invoice-date', v => { state.invoice.date = v; });
    bindInput('invoice-due-date', v => { state.invoice.dueDate = v; });
    bindInput('invoice-po', v => { state.invoice.poNumber = v; });
    bindInput('invoice-pos', v => { state.invoice.placeOfSupply = v; });
    bindInput('invoice-reverse-charge', v => { state.invoice.reverseCharge = v; });
    bindInput('invoice-vehicle', v => { state.invoice.vehicleNo = v; });
    bindInput('invoice-notes', v => { state.invoice.notes = v; });
    bindInput('invoice-terms', v => { state.invoice.terms = v; });
    bindInput('extra-charges', v => { state.extraCharges = parseFloat(v) || 0; });

    // Tax override radio
    const taxTypeRadios = document.querySelectorAll('input[name="taxTypeOverride"]');
    taxTypeRadios.forEach(radio => {
      radio.addEventListener('change', e => {
        state.taxTypeOverride = e.target.value;
        recalculateAndRender();
      });
    });

    // Logo upload
    bindImageUpload('logo-input', 'logo-preview', dataUrl => {
      state.business.logo = dataUrl;
      recalculateAndRender();
    });
    const removeLogoBtn = document.getElementById('btn-remove-logo');
    if (removeLogoBtn) {
      removeLogoBtn.addEventListener('click', () => {
        state.business.logo = '';
        updateImagePreview('logo-preview', '');
        recalculateAndRender();
      });
    }

    // Signature upload
    bindImageUpload('signature-input', 'signature-preview', dataUrl => {
      state.business.signature = dataUrl;
      recalculateAndRender();
    });
    const removeSigBtn = document.getElementById('btn-remove-signature');
    if (removeSigBtn) {
      removeSigBtn.addEventListener('click', () => {
        state.business.signature = '';
        updateImagePreview('signature-preview', '');
        recalculateAndRender();
      });
    }

    // "Save as Default Business Profile" button
    const saveProfileBtn = document.getElementById('btn-save-profile');
    if (saveProfileBtn) {
      saveProfileBtn.addEventListener('click', async () => {
        localStorage.setItem('gst_inv_default_profile', JSON.stringify(state.business));
        if (ApiClient.connected) {
          const ok = await ApiClient.saveProfile(state.business);
          if (ok) {
            showToast('Business profile saved to SQLite Database!', 'success');
            return;
          }
        }
        showToast('Business profile saved as default!', 'success');
      });
    }
  }

  // Handle image files via FileReader
  function bindImageUpload(inputId, previewId, callback) {
    const input = document.getElementById(inputId);
    if (!input) return;
    input.addEventListener('change', e => {
      const file = e.target.files[0];
      if (!file) return;
      if (file.size > 2 * 1024 * 1024) {
        showToast('Image file too large (Max 2MB)', 'error');
        return;
      }
      const reader = new FileReader();
      reader.onload = ev => {
        callback(ev.target.result);
        updateImagePreview(previewId, ev.target.result);
      };
      reader.readAsDataURL(file);
    });
  }

  // Bind table row event delegation
  function bindTableEvents() {
    const tbody = document.getElementById('items-tbody');
    if (!tbody) return;

    tbody.addEventListener('input', e => {
      const tr = e.target.closest('tr');
      if (!tr) return;
      const index = parseInt(tr.querySelector('button.btn-remove-row').getAttribute('data-index'), 10);
      if (isNaN(index) || !state.items[index]) return;

      const item = state.items[index];
      if (e.target.classList.contains('item-desc')) item.description = e.target.value;
      if (e.target.classList.contains('item-hsn')) item.hsn = e.target.value;
      if (e.target.classList.contains('item-qty')) item.quantity = parseFloat(e.target.value) || 0;
      if (e.target.classList.contains('item-rate')) item.rate = parseFloat(e.target.value) || 0;
      if (e.target.classList.contains('item-disc')) item.discount = parseFloat(e.target.value) || 0;
      if (e.target.classList.contains('item-gst')) item.gstRate = parseFloat(e.target.value) || 0;

      recalculateAndRender();
    });

    tbody.addEventListener('change', e => {
      if (e.target.classList.contains('item-gst')) {
        const tr = e.target.closest('tr');
        if (!tr) return;
        const index = parseInt(tr.querySelector('button.btn-remove-row').getAttribute('data-index'), 10);
        if (state.items[index]) {
          state.items[index].gstRate = parseFloat(e.target.value) || 0;
          recalculateAndRender();
        }
      }
    });

    tbody.addEventListener('click', e => {
      const btn = e.target.closest('.btn-remove-row');
      if (!btn) return;
      const index = parseInt(btn.getAttribute('data-index'), 10);
      if (state.items.length <= 1) {
        showToast('At least one item is required in the invoice', 'warning');
        return;
      }
      state.items.splice(index, 1);
      renderItemsTableRows();
      recalculateAndRender();
    });

    // Add item button
    const addItemBtn = document.getElementById('btn-add-item');
    if (addItemBtn) {
      addItemBtn.addEventListener('click', () => {
        state.items.push({
          id: 'item-' + Date.now(),
          description: '',
          hsn: '',
          quantity: 1,
          rate: 0,
          discount: 0,
          gstRate: 18,
          taxable: 0,
          total: 0
        });
        renderItemsTableRows();
        recalculateAndRender();
        const rows = tbody.querySelectorAll('tr');
        const lastRow = rows[rows.length - 1];
        if (lastRow) {
          const inp = lastRow.querySelector('.item-desc');
          if (inp) inp.focus();
        }
      });
    }
  }

  // Bind top navbar & preview toolbar
  function bindToolbarEvents() {
    // Print / Save as PDF button
    const printBtns = document.querySelectorAll('.action-print');
    printBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        window.print();
      });
    });

    // New Invoice button
    const newInvBtn = document.getElementById('btn-new-invoice');
    if (newInvBtn) {
      newInvBtn.addEventListener('click', () => {
        if (confirm('Create a new invoice? Make sure you have saved your current invoice if needed.')) {
          createNewInvoice();
        }
      });
    }

    // Save Invoice to History button
    const saveInvBtn = document.getElementById('btn-save-invoice');
    if (saveInvBtn) {
      saveInvBtn.addEventListener('click', () => {
        saveInvoiceToHistory();
      });
    }

    // Load Sample Data button
    const sampleBtn = document.getElementById('btn-load-sample');
    if (sampleBtn) {
      sampleBtn.addEventListener('click', () => {
        state = JSON.parse(JSON.stringify(DEFAULT_STATE));
        populateFormFromState();
        recalculateAndRender();
        showToast('Sample invoice data loaded!', 'info');
      });
    }

    // Template Selector
    const templateSelect = document.getElementById('template-select');
    if (templateSelect) {
      templateSelect.value = state.ui.template;
      templateSelect.addEventListener('change', e => {
        state.ui.template = e.target.value;
        recalculateAndRender();
      });
    }

    // Color theme picker
    const colorDots = document.querySelectorAll('.color-dot');
    colorDots.forEach(dot => {
      dot.addEventListener('click', () => {
        colorDots.forEach(d => d.classList.remove('active'));
        dot.classList.add('active');
        state.ui.accentColor = dot.getAttribute('data-color');
        document.documentElement.style.setProperty('--inv-accent', state.ui.accentColor);
        recalculateAndRender();
      });
    });

    // Zoom Controls
    const zoomInBtn = document.getElementById('btn-zoom-in');
    const zoomOutBtn = document.getElementById('btn-zoom-out');
    const zoomResetBtn = document.getElementById('btn-zoom-reset');
    const invoiceSheet = document.getElementById('invoice-sheet');

    function applyZoom(z) {
      state.ui.zoom = Math.min(130, Math.max(60, z));
      if (invoiceSheet) {
        invoiceSheet.style.transform = `scale(${state.ui.zoom / 100})`;
      }
      const label = document.getElementById('zoom-label');
      if (label) label.textContent = state.ui.zoom + '%';
    }

    if (zoomInBtn) zoomInBtn.addEventListener('click', () => applyZoom(state.ui.zoom + 10));
    if (zoomOutBtn) zoomOutBtn.addEventListener('click', () => applyZoom(state.ui.zoom - 10));
    if (zoomResetBtn) zoomResetBtn.addEventListener('click', () => applyZoom(100));
  }

  // Create new fresh invoice (preserving business info & settings)
  function createNewInvoice() {
    let nextNum = 'INV-' + (Math.floor(Math.random() * 900) + 100);
    const existingHistory = getSavedInvoices();
    if (existingHistory.length > 0) {
      nextNum = 'INV-' + (existingHistory.length + 1).toString().padStart(3, '0');
    }

    const currentBusiness = JSON.parse(JSON.stringify(state.business));
    const currentGstEnabled = state.gstEnabled !== false;
    const currentDiscountEnabled = !!state.discountEnabled;
    const currentRoundOff = JSON.parse(JSON.stringify(state.roundOff || { mode: 'auto', type: 'subtract', manualValue: 0 }));

    state = {
      gstEnabled: currentGstEnabled,
      discountEnabled: currentDiscountEnabled,
      roundOff: currentRoundOff,
      business: currentBusiness,
      client: { name: '', gstin: '', state: '', stateCode: '', phone: '', email: '', address: '' },
      shipping: { enabled: false, name: '', address: '', state: '' },
      invoice: {
        title: currentGstEnabled ? 'TAX INVOICE' : 'INVOICE',
        number: nextNum,
        date: new Date().toISOString().split('T')[0],
        dueDate: new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0],
        poNumber: '',
        placeOfSupply: '',
        reverseCharge: 'No',
        vehicleNo: '',
        notes: 'Thank you for your business!',
        terms: currentBusiness.terms || '1. Goods once sold cannot be returned.\n2. Subject to local jurisdiction.'
      },
      items: [
        {
          id: 'item-' + Date.now(),
          description: '',
          hsn: '',
          quantity: 1,
          rate: 0,
          discount: 0,
          gstRate: 18,
          taxable: 0,
          total: 0
        }
      ],
      extraCharges: 0,
      taxTypeOverride: 'auto',
      ui: state.ui
    };

    populateFormFromState();
    recalculateAndRender();
    showToast('New invoice created!', 'info');
  }

  // Invoice History Management (SQLite + localStorage cache)
  function getSavedInvoices() {
    try {
      const data = localStorage.getItem('gst_invoices_history');
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  }

  async function saveInvoiceToHistory() {
    try {
      const history = getSavedInvoices();
      const existingIndex = history.findIndex(inv => inv.invoiceNumber === state.invoice.number || (inv.invoice && inv.invoice.number === state.invoice.number));

      const record = {
        id: state.invoice.number || ('INV-' + Date.now()),
        invoiceNumber: state.invoice.number,
        date: state.invoice.date,
        clientName: state.client.name || 'Unnamed Client',
        amount: state.calculations ? state.calculations.grandTotal : 0,
        gstEnabled: state.gstEnabled !== false,
        discountEnabled: !!state.discountEnabled,
        savedAt: new Date().toISOString(),
        data: JSON.parse(JSON.stringify(state))
      };

      // Always save to localStorage
      if (existingIndex >= 0) {
        history[existingIndex] = record;
      } else {
        history.unshift(record);
      }
      localStorage.setItem('gst_invoices_history', JSON.stringify(history));

      // Save to SQLite database if connected
      if (ApiClient.connected) {
        const ok = await ApiClient.saveInvoice(record);
        if (ok) {
          showToast(`Invoice #${state.invoice.number} saved to Database!`, 'success');
        } else {
          showToast(`Invoice #${state.invoice.number} saved to local storage!`, 'success');
        }
      } else {
        showToast(`Invoice #${state.invoice.number} saved to history!`, 'success');
      }

      await updateHistoryBadge();
    } catch (e) {
      showToast('Error saving to history: ' + e.message, 'error');
    }
  }

  async function updateHistoryBadge() {
    const badge = document.getElementById('history-count-badge');
    if (!badge) return;

    if (ApiClient.connected) {
      const dbInvoices = await ApiClient.getInvoices();
      if (dbInvoices) {
        badge.textContent = dbInvoices.length;
        return;
      }
    }
    const history = getSavedInvoices();
    badge.textContent = history.length;
  }

  // Modal Handlers (Saved Invoices & Backup)
  function bindModalEvents() {
    const historyModal = document.getElementById('modal-history');
    const openHistoryBtn = document.getElementById('btn-open-history');
    const closeHistoryBtns = document.querySelectorAll('.close-modal');

    if (openHistoryBtn && historyModal) {
      openHistoryBtn.addEventListener('click', async () => {
        await renderHistoryList();
        historyModal.classList.add('active');
      });
    }

    closeHistoryBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const modal = btn.closest('.modal-overlay');
        if (modal) modal.classList.remove('active');
      });
    });

    // Close when clicking overlay backdrop
    window.addEventListener('click', e => {
      if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active');
      }
    });

    // History search filter
    const searchInput = document.getElementById('history-search');
    if (searchInput) {
      searchInput.addEventListener('input', async e => {
        await renderHistoryList(e.target.value);
      });
    }

    // Export all data as JSON
    const exportBtn = document.getElementById('btn-export-backup');
    if (exportBtn) {
      exportBtn.addEventListener('click', async () => {
        let backupData;
        if (ApiClient.connected) {
          backupData = await ApiClient.getBackup();
        }
        if (!backupData) {
          backupData = {
            version: '2.0',
            exportedAt: new Date().toISOString(),
            currentDraft: state,
            savedInvoices: getSavedInvoices(),
            defaultProfile: localStorage.getItem('gst_inv_default_profile')
          };
        }

        const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Invoice_Backup_${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
        showToast('Backup JSON file downloaded!', 'success');
      });
    }

    // Import data from JSON
    const importInput = document.getElementById('input-import-backup');
    if (importInput) {
      importInput.addEventListener('change', e => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = async ev => {
          try {
            const data = JSON.parse(ev.target.result);

            // Restore in SQLite Database if connected
            if (ApiClient.connected) {
              await ApiClient.restoreBackup(data);
            }

            // Also restore in localStorage
            if (data.savedInvoices && Array.isArray(data.savedInvoices)) {
              localStorage.setItem('gst_invoices_history', JSON.stringify(data.savedInvoices));
            }
            if (data.defaultProfile) {
              localStorage.setItem('gst_inv_default_profile', typeof data.defaultProfile === 'string' ? data.defaultProfile : JSON.stringify(data.defaultProfile));
            }
            if (data.currentDraft) {
              state = data.currentDraft;
              if (state.gstEnabled === undefined) state.gstEnabled = true;
              if (state.discountEnabled === undefined) state.discountEnabled = false;
              if (!state.roundOff) state.roundOff = { mode: 'auto', type: 'subtract', manualValue: 0 };
              populateFormFromState();
              recalculateAndRender();
            }

            await updateHistoryBadge();
            await renderHistoryList();
            showToast('Backup restored successfully!', 'success');
          } catch (err) {
            showToast('Invalid backup JSON file: ' + err.message, 'error');
          }
        };
        reader.readAsText(file);
      });
    }
  }

  // Render Saved Invoices inside the modal
  async function renderHistoryList(filterTerm = '') {
    const listEl = document.getElementById('history-items-container');
    if (!listEl) return;

    let history = [];
    if (ApiClient.connected) {
      const dbInvoices = await ApiClient.getInvoices(filterTerm);
      if (dbInvoices) {
        history = dbInvoices;
      } else {
        history = getSavedInvoices();
      }
    } else {
      history = getSavedInvoices();
    }

    const filtered = history.filter(inv => {
      if (!filterTerm) return true;
      const term = filterTerm.toLowerCase();
      return (
        (inv.invoiceNumber && inv.invoiceNumber.toLowerCase().includes(term)) ||
        (inv.clientName && inv.clientName.toLowerCase().includes(term)) ||
        (inv.date && inv.date.includes(term))
      );
    });

    if (filtered.length === 0) {
      listEl.innerHTML = `
        <div style="text-align: center; padding: 2rem; color: #94a3b8;">
          <p style="font-size: 1.1rem; margin-bottom: 0.5rem;">No saved invoices found</p>
          <span style="font-size: 0.8rem;">Click "Save to History" on any invoice to store it permanently in the Database.</span>
        </div>
      `;
      return;
    }

    listEl.innerHTML = filtered.map(inv => `
      <div class="history-item">
        <div class="history-info">
          <h4>
            <strong>#${escapeHtml(inv.invoiceNumber)}</strong> - ${escapeHtml(inv.clientName)}
            <span class="${inv.gstEnabled !== false ? 'badge-gst' : 'badge-nongst'}" style="margin-left: 6px; font-size: 0.65rem;">
              ${inv.gstEnabled !== false ? 'GST' : 'Non-GST'}
            </span>
          </h4>
          <p>Date: ${inv.date || '-'} &nbsp;|&nbsp; Amount: ₹${Number(inv.amount || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</p>
        </div>
        <div class="history-actions">
          <button class="btn btn-sm btn-outline btn-load-inv" data-id="${escapeHtml(inv.id)}">Open</button>
          <button class="btn btn-sm btn-outline btn-dup-inv" data-id="${escapeHtml(inv.id)}">Duplicate</button>
          <button class="btn btn-sm btn-danger btn-del-inv" data-id="${escapeHtml(inv.id)}">Delete</button>
        </div>
      </div>
    `).join('');

    // Bind action buttons on each history item
    listEl.querySelectorAll('.btn-load-inv').forEach(b => {
      b.addEventListener('click', () => {
        const id = b.getAttribute('data-id');
        const item = history.find(x => x.id === id);
        if (item && item.data) {
          state = item.data;
          if (state.gstEnabled === undefined) state.gstEnabled = true;
          if (state.discountEnabled === undefined) state.discountEnabled = false;
          if (!state.roundOff) state.roundOff = { mode: 'auto', type: 'subtract', manualValue: 0 };
          populateFormFromState();
          recalculateAndRender();
          document.getElementById('modal-history').classList.remove('active');
          showToast(`Invoice #${item.invoiceNumber} loaded!`, 'info');
        }
      });
    });

    listEl.querySelectorAll('.btn-dup-inv').forEach(b => {
      b.addEventListener('click', () => {
        const id = b.getAttribute('data-id');
        const item = history.find(x => x.id === id);
        if (item && item.data) {
          state = JSON.parse(JSON.stringify(item.data));
          state.invoice.number = state.invoice.number + '-COPY';
          state.invoice.date = new Date().toISOString().split('T')[0];
          populateFormFromState();
          recalculateAndRender();
          document.getElementById('modal-history').classList.remove('active');
          showToast(`Duplicated into #${state.invoice.number}`, 'info');
        }
      });
    });

    listEl.querySelectorAll('.btn-del-inv').forEach(b => {
      b.addEventListener('click', async () => {
        const id = b.getAttribute('data-id');
        if (confirm('Are you sure you want to delete this invoice?')) {
          if (ApiClient.connected) {
            await ApiClient.deleteInvoice(id);
          }
          const newHist = getSavedInvoices().filter(x => x.id !== id);
          localStorage.setItem('gst_invoices_history', JSON.stringify(newHist));

          await updateHistoryBadge();
          await renderHistoryList(filterTerm);
          showToast('Invoice deleted', 'warning');
        }
      });
    });
  }

  // Toast Notification System
  function showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }

  // Run on DOM load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
