// Invoice Templates Engine for Indian Invoices (GST & Non-GST)
// Supports Modern, Classic, and Corporate layouts with dynamic colors

const InvoiceTemplates = {
  // Helper for formatting Indian Rupee currency
  formatCurrency(num) {
    if (num === null || num === undefined || isNaN(num)) return "₹ 0.00";
    return "₹ " + Number(num).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  formatNumber(num) {
    if (num === null || num === undefined || isNaN(num)) return "0.00";
    return Number(num).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  // Generate UPI payment string (Supports optional fixed or open amount)
  getUPIString(upiId, payeeName, amount, invoiceNo) {
    if (!upiId) return "";
    const cleanId = encodeURIComponent(upiId.trim());
    const name = encodeURIComponent((payeeName || "Business").trim());
    const note = encodeURIComponent("Invoice " + (invoiceNo || "Payment"));
    let amtParam = "";
    if (amount !== null && amount !== undefined && amount !== "" && !isNaN(amount) && Number(amount) > 0) {
      amtParam = `&am=${Number(amount).toFixed(2)}`;
    }
    return `upi://pay?pa=${cleanId}&pn=${name}${amtParam}&cu=INR&tn=${note}`;
  },

  // Main render dispatcher
  render(data, templateName = "modern", accentColor = "#1e40af") {
    switch (templateName) {
      case "classic":
        return this.renderClassic(data, accentColor);
      case "corporate":
        return this.renderCorporate(data, accentColor);
      case "modern":
      default:
        return this.renderModern(data, accentColor);
    }
  },

  // Generate QR code SVG with configurable amount (Custom amount or Open amount)
  renderQRCode(data, accentColor = "#1e40af") {
    if (!data.business || !data.business.upiId || typeof QRCodeGenerator === "undefined") {
      return "";
    }
    const upiId = (data.business.upiId || "").trim();
    if (!upiId) return "";

    // Amount handling:
    // If invoice maker entered an amount (e.g. 300), QR code has &am=300.00
    // If left blank / empty, QR code has NO &am= parameter so customer can choose and enter amount in their UPI app
    let qrAmount = null;
    let labelAmount = "";

    const rawVal = data.payment ? data.payment.qrCustomAmount : null;
    if (rawVal !== null && rawVal !== undefined && rawVal !== "" && !isNaN(rawVal) && Number(rawVal) > 0) {
      qrAmount = Number(rawVal);
      labelAmount = this.formatCurrency(qrAmount);
    }

    const upiString = this.getUPIString(
      upiId,
      data.business.name,
      qrAmount,
      data.invoice ? data.invoice.number : ""
    );

    try {
      const qrSvg = QRCodeGenerator.generateSVG(upiString, 92);
      return `
        <div style="display:flex; flex-direction:column; align-items:center; text-align:center; padding:4px;">
          ${qrSvg}
          <span style="font-size:7.5pt; color:#334155; margin-top:3px; font-weight:700;">Scan to Pay via UPI</span>
          ${labelAmount ? `<span style="font-size:7.5pt; color:${accentColor}; font-weight:800; margin-top:1px;">${labelAmount}</span>` : ''}
          <span style="font-size:6.5pt; color:#64748b;">${upiId}</span>
        </div>
      `;
    } catch (e) {
      console.error("QR Code generation error:", e);
      return "";
    }
  },

  // Generate HSN / SAC Tax Summary Table (Only when GST is enabled)
  renderHSNSummary(data, accentColor) {
    if (data.gstEnabled === false) return "";

    const summary = data.calculations.hsnSummary || [];
    if (summary.length === 0) return "";

    const isIntra = data.calculations.isIntraState;

    return `
      <div style="margin-top: 10px; margin-bottom: 10px; break-inside: avoid;">
        <div style="font-size: 8pt; font-weight: 700; color: ${accentColor}; text-transform: uppercase; margin-bottom: 4px;">
          HSN / SAC Tax Summary
        </div>
        <table style="width: 100%; border-collapse: collapse; font-size: 7.5pt; text-align: right;">
          <thead>
            <tr style="background-color: #f8fafc; border-top: 1px solid #cbd5e1; border-bottom: 1px solid #cbd5e1;">
              <th style="padding: 5px; text-align: left;">HSN / SAC</th>
              <th style="padding: 5px;">Taxable Value</th>
              ${isIntra ? `
                <th style="padding: 5px;">CGST Rate</th>
                <th style="padding: 5px;">CGST Amt</th>
                <th style="padding: 5px;">SGST Rate</th>
                <th style="padding: 5px;">SGST Amt</th>
              ` : `
                <th style="padding: 5px;">IGST Rate</th>
                <th style="padding: 5px;">IGST Amt</th>
              `}
              <th style="padding: 5px;">Total Tax</th>
            </tr>
          </thead>
          <tbody>
            ${summary.map(item => `
              <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="padding: 5px; text-align: left; font-weight: 600;">${item.hsn || '-'}</td>
                <td style="padding: 5px;">${this.formatNumber(item.taxable)}</td>
                ${isIntra ? `
                  <td style="padding: 5px;">${item.cgstRate}%</td>
                  <td style="padding: 5px;">${this.formatNumber(item.cgstAmount)}</td>
                  <td style="padding: 5px;">${item.sgstRate}%</td>
                  <td style="padding: 5px;">${this.formatNumber(item.sgstAmount)}</td>
                ` : `
                  <td style="padding: 5px;">${item.igstRate}%</td>
                  <td style="padding: 5px;">${this.formatNumber(item.igstAmount)}</td>
                `}
                <td style="padding: 5px; font-weight: 600;">${this.formatNumber(item.totalTax)}</td>
              </tr>
            `).join('')}
            <tr style="font-weight: 700; background-color: #f8fafc; border-top: 1px solid #cbd5e1;">
              <td style="padding: 5px; text-align: left;">Total</td>
              <td style="padding: 5px;">${this.formatNumber(data.calculations.totalTaxable)}</td>
              ${isIntra ? `
                <td style="padding: 5px;">-</td>
                <td style="padding: 5px;">${this.formatNumber(data.calculations.totalCGST)}</td>
                <td style="padding: 5px;">-</td>
                <td style="padding: 5px;">${this.formatNumber(data.calculations.totalSGST)}</td>
              ` : `
                <td style="padding: 5px;">-</td>
                <td style="padding: 5px;">${this.formatNumber(data.calculations.totalIGST)}</td>
              `}
              <td style="padding: 5px;">${this.formatNumber(data.calculations.totalTax)}</td>
            </tr>
          </tbody>
        </table>
      </div>
    `;
  },

  // Helper for resolved invoice title
  getInvoiceTitle(data) {
    if (data.invoice && data.invoice.title) {
      return data.invoice.title;
    }
    return data.gstEnabled !== false ? "TAX INVOICE" : "INVOICE";
  },

  // ==========================================
  // 1. MODERN MINIMALIST TEMPLATE
  // ==========================================
  renderModern(data, accentColor) {
    const isGST = data.gstEnabled !== false;
    const isIntra = isGST && data.calculations.isIntraState;
    const hasDiscount = data.discountEnabled === true;
    const qrCodeHtml = this.renderQRCode(data, accentColor);
    const hsnTableHtml = this.renderHSNSummary(data, accentColor);
    const invoiceTitle = this.getInvoiceTitle(data);
    const amountPaid = Number((data.payment && data.payment.amountPaid) || 0);
    const balanceDue = Math.max(0, Number((data.calculations && data.calculations.grandTotal) || 0) - amountPaid);

    return `
      <div style="font-family: inherit; color: #1e293b; line-height: 1.4; font-size: 8.5pt;">
        <!-- Top Header: Logo + Company Info & Invoice Badge -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; padding-bottom: 12px; border-bottom: 2px solid ${accentColor};">
          <div style="display: flex; gap: 14px; align-items: center; max-width: 60%;">
            ${data.business.logo ? `
              <img src="${data.business.logo}" alt="Logo" style="max-height: 70px; max-width: 150px; object-fit: contain;">
            ` : ''}
            <div>
              <h1 style="font-size: 16pt; font-weight: 800; color: ${accentColor}; margin: 0; line-height: 1.2;">
                ${data.business.name || 'Your Company Name'}
              </h1>
              <div style="font-size: 8pt; color: #475569; margin-top: 4px; white-space: pre-line;">
                ${data.business.address || ''}
              </div>
              <div style="font-size: 8pt; color: #334155; margin-top: 4px; font-weight: 500;">
                ${(isGST && data.business.gstin) ? `<span><strong>GSTIN:</strong> ${data.business.gstin}</span> | ` : ''}
                ${data.business.state ? `<span><strong>State:</strong> ${data.business.state}</span>` : ''}
                ${data.business.pan ? ` | <span><strong>PAN:</strong> ${data.business.pan}</span>` : ''}
              </div>
              <div style="font-size: 7.5pt; color: #64748b; margin-top: 2px;">
                ${data.business.email ? `Email: ${data.business.email} ` : ''}
                ${data.business.phone ? `| Phone: ${data.business.phone}` : ''}
              </div>
            </div>
          </div>

          <div style="text-align: right;">
            <div style="display: inline-block; background-color: ${accentColor}; color: #ffffff; padding: 5px 14px; border-radius: 4px; font-weight: 700; font-size: 10pt; letter-spacing: 0.05em; text-transform: uppercase;">
              ${invoiceTitle}
            </div>
            <div style="margin-top: 6px; font-size: 8.5pt;">
              <span style="color: #64748b;">Invoice No:</span> <strong style="color: #0f172a; font-size: 9.5pt;">${data.invoice.number || 'INV-001'}</strong>
            </div>
            <div style="font-size: 8pt; color: #475569; margin-top: 2px;">
              <span>Invoice Date:</span> <strong>${data.invoice.date || '-'}</strong>
            </div>
            ${data.invoice.dueDate ? `
              <div style="font-size: 8pt; color: #475569;">
                <span>Due Date:</span> <strong>${data.invoice.dueDate}</strong>
              </div>
            ` : ''}
            ${data.invoice.poNumber ? `
              <div style="font-size: 8pt; color: #475569;">
                <span>PO / Ref No:</span> <strong>${data.invoice.poNumber}</strong>
              </div>
            ` : ''}
            ${(isGST && data.invoice.placeOfSupply) ? `
              <div style="font-size: 8pt; color: #475569; margin-top: 2px;">
                <span>Place of Supply:</span> <strong>${data.invoice.placeOfSupply}</strong>
              </div>
            ` : ''}
          </div>
        </div>

        <!-- Parties Section: Bill To & Ship To -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 10px; margin-bottom: 12px; font-size: 8pt;">
          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 4px; padding: 9px 11px;">
            <div style="font-weight: 700; color: ${accentColor}; text-transform: uppercase; font-size: 7.5pt; margin-bottom: 3px; letter-spacing: 0.04em;">
              Billed To (Customer Details)
            </div>
            <div style="font-size: 9.5pt; font-weight: 700; color: #0f172a; margin-bottom: 2px;">
              ${data.client.name || 'Client Name'}
            </div>
            <div style="color: #475569; white-space: pre-line; margin-bottom: 4px;">
              ${data.client.address || 'Client Address'}
            </div>
            ${(isGST && data.client.gstin) ? `<div><strong>GSTIN:</strong> ${data.client.gstin}</div>` : ''}
            ${data.client.state ? `<div><strong>State:</strong> ${data.client.state}</div>` : ''}
            ${data.client.phone ? `<div><strong>Phone:</strong> ${data.client.phone}</div>` : ''}
            ${data.client.email ? `<div><strong>Email:</strong> ${data.client.email}</div>` : ''}
          </div>

          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 4px; padding: 9px 11px;">
            <div style="font-weight: 700; color: ${accentColor}; text-transform: uppercase; font-size: 7.5pt; margin-bottom: 3px; letter-spacing: 0.04em;">
              Shipped To (Delivery Details)
            </div>
            ${data.shipping.enabled ? `
              <div style="font-size: 9pt; font-weight: 700; color: #0f172a; margin-bottom: 2px;">
                ${data.shipping.name || data.client.name || '-'}
              </div>
              <div style="color: #475569; white-space: pre-line; margin-bottom: 4px;">
                ${data.shipping.address || data.client.address || '-'}
              </div>
              <div><strong>State:</strong> ${data.shipping.state || data.client.state || '-'}</div>
            ` : `
              <div style="color: #64748b; font-style: italic; margin-top: 4px;">
                Same as Billed To Address
              </div>
            `}
            <div style="margin-top: 6px; padding-top: 4px; border-top: 1px dashed #cbd5e1; font-size: 7.5pt;">
              ${isGST ? `<div><strong>Reverse Charge:</strong> ${data.invoice.reverseCharge || 'No'}</div>` : ''}
              ${data.invoice.vehicleNo ? `<div><strong>Vehicle / Transport No:</strong> ${data.invoice.vehicleNo}</div>` : ''}
            </div>
          </div>
        </div>

        <!-- Items Table -->
        <table class="inv-items-table" style="width: 100%; border-collapse: collapse; font-size: 8pt; margin-bottom: 10px;">
          <thead>
            <tr style="background-color: ${accentColor}; color: #ffffff;">
              <th style="padding: 7px 6px; text-align: center; width: 25px;">#</th>
              <th style="padding: 7px 6px; text-align: left;">Item Description</th>
              ${isGST ? `<th style="padding: 7px 6px; text-align: center; width: 68px;">HSN/SAC</th>` : ''}
              <th style="padding: 7px 6px; text-align: center; width: 50px;">Qty</th>
              <th style="padding: 7px 6px; text-align: right; width: 80px;">Rate (₹)</th>
              ${hasDiscount ? `<th style="padding: 7px 6px; text-align: right; width: 60px;">Disc (₹)</th>` : ''}
              ${isGST ? `<th style="padding: 7px 6px; text-align: right; width: 80px;">Taxable (₹)</th>` : ''}
              ${isGST ? `<th style="padding: 7px 6px; text-align: center; width: 52px;">GST %</th>` : ''}
              <th style="padding: 7px 6px; text-align: right; width: 90px;">Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            ${data.items.map((item, index) => `
              <tr style="border-bottom: 1px solid #e2e8f0; background-color: ${index % 2 === 0 ? '#ffffff' : '#f8fafc'};">
                <td style="padding: 6px; text-align: center; color: #64748b;">${index + 1}</td>
                <td style="padding: 6px; text-align: left; font-weight: 500; color: #0f172a;">
                  ${item.description || '-'}
                </td>
                ${isGST ? `<td style="padding: 6px; text-align: center; color: #475569;">${item.hsn || '-'}</td>` : ''}
                <td style="padding: 6px; text-align: center;">${item.quantity || 1}</td>
                <td style="padding: 6px; text-align: right;">${this.formatNumber(item.rate)}</td>
                ${hasDiscount ? `<td style="padding: 6px; text-align: right; color: #dc2626;">${item.discount > 0 ? this.formatNumber(item.discount) : '-'}</td>` : ''}
                ${isGST ? `<td style="padding: 6px; text-align: right; font-weight: 500;">${this.formatNumber(item.taxable)}</td>` : ''}
                ${isGST ? `<td style="padding: 6px; text-align: center; font-weight: 600;">${item.gstRate}%</td>` : ''}
                <td style="padding: 6px; text-align: right; font-weight: 700; color: #0f172a;">${this.formatNumber(item.total)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <!-- Description / Package Notes Section (Printed below Items Table and above Payment Section) -->
        ${(data.invoice && data.invoice.description && data.invoice.description.trim()) ? `
          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-left: 3px solid ${accentColor}; border-radius: 4px; padding: 8px 12px; margin-bottom: 10px; font-size: 8pt; color: #334155; white-space: pre-line; line-height: 1.45;">
            ${data.invoice.description}
          </div>
        ` : ''}

        <!-- Totals & Calculations Section -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 15px; margin-bottom: 10px; break-inside: avoid;">
          <!-- Left: Amount in words & Bank info -->
          <div style="flex: 1; font-size: 8pt;">
            <div style="background-color: #f1f5f9; padding: 7px 10px; border-radius: 4px; border-left: 3px solid ${accentColor}; margin-bottom: 8px;">
              <div style="font-size: 7pt; text-transform: uppercase; font-weight: 700; color: #64748b;">Invoice Amount in Words:</div>
              <div style="font-weight: 700; color: #0f172a; margin-top: 2px;">
                ${data.calculations.amountInWords || 'Zero Rupees Only'}
              </div>
            </div>

            <!-- Bank & Payment Details -->
            ${(data.business.bankName || data.business.accountNo || data.business.upiId) ? `
              <div style="border: 1px solid #e2e8f0; border-radius: 4px; padding: 9px 11px; display: flex; justify-content: space-between; align-items: center; background: #ffffff;">
                <div style="font-size: 7.5pt; color: #334155; line-height: 1.45;">
                  <div style="font-weight: 700; color: ${accentColor}; text-transform: uppercase; margin-bottom: 3px;">Bank & Payment Details</div>
                  ${data.business.bankName ? `<div><strong>Bank:</strong> ${data.business.bankName}</div>` : ''}
                  ${data.business.accountNo ? `<div><strong>A/C No:</strong> ${data.business.accountNo}</div>` : ''}
                  ${data.business.ifsc ? `<div><strong>IFSC:</strong> ${data.business.ifsc}</div>` : ''}
                  ${data.business.branch ? `<div><strong>Branch:</strong> ${data.business.branch}</div>` : ''}
                  ${data.business.upiId ? `<div><strong>UPI ID:</strong> ${data.business.upiId}</div>` : ''}
                </div>
                ${qrCodeHtml}
              </div>
            ` : ''}
          </div>

          <!-- Right: Summary Totals Card -->
          <div style="width: 260px; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 4px; padding: 9px 11px; font-size: 8pt;">
            <div style="display: flex; justify-content: space-between; padding: 2px 0;">
              <span style="color: #64748b;">${isGST ? 'Taxable Subtotal:' : 'Subtotal:'}</span>
              <strong style="color: #0f172a;">${this.formatCurrency(data.calculations.totalTaxable)}</strong>
            </div>

            ${isGST ? `
              ${isIntra ? `
                <div style="display: flex; justify-content: space-between; padding: 2px 0; color: #475569;">
                  <span>Total CGST:</span>
                  <span>+ ${this.formatCurrency(data.calculations.totalCGST)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 2px 0; color: #475569;">
                  <span>Total SGST:</span>
                  <span>+ ${this.formatCurrency(data.calculations.totalSGST)}</span>
                </div>
              ` : `
                <div style="display: flex; justify-content: space-between; padding: 2px 0; color: #475569;">
                  <span>Total IGST:</span>
                  <span>+ ${this.formatCurrency(data.calculations.totalIGST)}</span>
                </div>
              `}
            ` : ''}

            ${data.calculations.extraCharges > 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 2px 0; color: #475569;">
                <span>Additional Charges:</span>
                <span>+ ${this.formatCurrency(data.calculations.extraCharges)}</span>
              </div>
            ` : ''}

            ${data.calculations.roundOff !== 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 2px 0; color: #64748b;">
                <span>Round Off:</span>
                <span>${data.calculations.roundOff > 0 ? '+' : ''}${this.formatNumber(data.calculations.roundOff)}</span>
              </div>
            ` : ''}

            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 2px solid ${accentColor}; margin-top: 6px; padding-top: 6px; font-size: 9.5pt; font-weight: 800; color: ${accentColor};">
              <span>Grand Total:</span>
              <span style="font-size: 11pt;">${this.formatCurrency(data.calculations.grandTotal)}</span>
            </div>

            ${amountPaid > 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 4px 0 2px 0; color: #166534; font-weight: 700; font-size: 8.5pt; border-top: 1px dashed #cbd5e1; margin-top: 5px;">
                <span>Amount Received:</span>
                <span>- ${this.formatCurrency(amountPaid)}</span>
              </div>
              ${balanceDue <= 0.01 ? `
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 4px 6px; background: #dcfce7; color: #166534; font-weight: 800; font-size: 9pt; border-radius: 4px; margin-top: 3px;">
                  <span>Payment Status:</span>
                  <span>✓ Fully Paid</span>
                </div>
              ` : `
                <div style="display: flex; justify-content: space-between; padding: 3px 0 1px 0; color: #dc2626; font-weight: 800; font-size: 9.5pt;">
                  <span>Balance Due:</span>
                  <span>${this.formatCurrency(balanceDue)}</span>
                </div>
              `}
            ` : ''}
          </div>
        </div>

        <!-- HSN Summary Table (Only if GST) -->
        ${hsnTableHtml}

        <!-- Bottom: Terms & Authorized Signatory -->
        <div style="display: flex; justify-content: space-between; align-items: flex-end; gap: 20px; margin-top: 10px; padding-top: 8px; border-top: 1px solid #e2e8f0; break-inside: avoid;">
          <div style="flex: 1; font-size: 7pt; color: #64748b;">
            <div style="font-weight: 700; text-transform: uppercase; color: #475569; margin-bottom: 2px;">Terms & Conditions</div>
            <div style="white-space: pre-line; line-height: 1.35;">
              ${data.invoice.terms || '1. Goods / services once delivered are non-refundable unless agreed in writing.\n2. Payment due within specified due date. Delayed payments may attract interest.\n3. Disputes subject to jurisdiction of seller\'s registered place of business.\n4. This is a computer-generated invoice and is valid without a physical signature.'}
            </div>
            ${data.invoice.notes ? `
              <div style="margin-top: 4px; font-style: italic;">
                <strong>Note:</strong> ${data.invoice.notes}
              </div>
            ` : ''}
          </div>

          <div style="width: 180px; text-align: center; font-size: 7.5pt;">
            <div style="font-weight: 700; color: #0f172a; margin-bottom: 20px;">
              For ${data.business.name || 'Company'}
            </div>
            ${data.business.signature ? `
              <img src="${data.business.signature}" alt="Signature" style="max-height: 48px; max-width: 140px; object-fit: contain; margin-bottom: 4px;">
            ` : `
              <div style="height: 38px;"></div>
            `}
            <div style="border-top: 1px dashed #94a3b8; padding-top: 3px; font-weight: 600; color: #334155;">
              Authorized Signatory
            </div>
          </div>
        </div>
      </div>
    `;
  },

  // ==========================================
  // 2. CLASSIC TEMPLATE
  // ==========================================
  renderClassic(data, accentColor) {
    const isGST = data.gstEnabled !== false;
    const isIntra = isGST && data.calculations.isIntraState;
    const hasDiscount = data.discountEnabled === true;
    const qrCodeHtml = this.renderQRCode(data, accentColor);
    const hsnTableHtml = this.renderHSNSummary(data, accentColor);
    const invoiceTitle = this.getInvoiceTitle(data);
    const amountPaid = Number((data.payment && data.payment.amountPaid) || 0);
    const balanceDue = Math.max(0, Number((data.calculations && data.calculations.grandTotal) || 0) - amountPaid);

    return `
      <div style="font-family: inherit; color: #000000; font-size: 8pt; border: 2px solid #000000; padding: 2px;">
        <!-- Top banner with Copies Checkbox -->
        <div style="border-bottom: 1px solid #000; padding: 5px; display: flex; justify-content: space-between; align-items: center; background: #f8fafc;">
          <div style="font-size: 7.5pt; font-weight: 600;">
            ${isGST ? `
              [✓] Original for Recipient &nbsp;&nbsp; [ ] Duplicate for Transporter &nbsp;&nbsp; [ ] Triplicate for Supplier
            ` : `
              [✓] Original for Recipient &nbsp;&nbsp; [ ] Duplicate for Records
            `}
          </div>
          <div style="font-size: 11.5pt; font-weight: 900; letter-spacing: 0.08em; text-transform: uppercase;">
            ${invoiceTitle}
          </div>
        </div>

        <!-- Supplier & Invoice Details Block -->
        <div style="display: grid; grid-template-columns: 1.2fr 1fr; border-bottom: 1px solid #000;">
          <div style="padding: 7px; border-right: 1px solid #000;">
            <div style="font-size: 7pt; text-transform: uppercase; font-weight: 700; color: #555;">Details of Supplier / Seller:</div>
            <div style="font-size: 12pt; font-weight: 800; margin: 2px 0;">${data.business.name || 'Business Name'}</div>
            <div style="white-space: pre-line; line-height: 1.35;">${data.business.address || ''}</div>
            ${(isGST && data.business.gstin) ? `<div style="margin-top: 4px;"><strong>GSTIN:</strong> ${data.business.gstin}</div>` : ''}
            <div><strong>State:</strong> ${data.business.state || '-'}</div>
            ${data.business.pan ? `<div><strong>PAN:</strong> ${data.business.pan}</div>` : ''}
            <div><strong>Contact:</strong> ${data.business.phone || ''} ${data.business.email ? `| ${data.business.email}` : ''}</div>
          </div>

          <div style="padding: 7px; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div style="display: flex; justify-content: space-between; margin-bottom: 3px;">
                <span><strong>Invoice No:</strong> ${data.invoice.number || 'INV-001'}</span>
                <span><strong>Date:</strong> ${data.invoice.date || '-'}</span>
              </div>
              ${data.invoice.dueDate ? `<div><strong>Due Date:</strong> ${data.invoice.dueDate}</div>` : ''}
              ${data.invoice.poNumber ? `<div><strong>Order / PO No:</strong> ${data.invoice.poNumber}</div>` : ''}
              ${isGST ? `<div><strong>Place of Supply:</strong> ${data.invoice.placeOfSupply || data.client.state || '-'}</div>` : ''}
              ${isGST ? `<div><strong>Reverse Charge:</strong> ${data.invoice.reverseCharge || 'No'}</div>` : ''}
              ${data.invoice.vehicleNo ? `<div><strong>Vehicle No:</strong> ${data.invoice.vehicleNo}</div>` : ''}
            </div>
            ${data.business.logo ? `
              <div style="text-align: right; margin-top: 4px;">
                <img src="${data.business.logo}" alt="Logo" style="max-height: 45px; max-width: 110px; object-fit: contain;">
              </div>
            ` : ''}
          </div>
        </div>

        <!-- Receiver / Consignee Block -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; border-bottom: 1px solid #000;">
          <div style="padding: 7px; border-right: 1px solid #000;">
            <div style="font-size: 7pt; text-transform: uppercase; font-weight: 700; color: #555;">Details of Receiver (Billed To):</div>
            <div style="font-size: 9.5pt; font-weight: 700; margin: 2px 0;">${data.client.name || 'Client Name'}</div>
            <div style="white-space: pre-line; line-height: 1.35;">${data.client.address || ''}</div>
            ${(isGST && data.client.gstin) ? `<div style="margin-top: 2px;"><strong>GSTIN:</strong> ${data.client.gstin}</div>` : ''}
            <div><strong>State:</strong> ${data.client.state || '-'}</div>
            ${data.client.phone ? `<div><strong>Phone:</strong> ${data.client.phone}</div>` : ''}
          </div>

          <div style="padding: 7px;">
            <div style="font-size: 7pt; text-transform: uppercase; font-weight: 700; color: #555;">Details of Consignee (Shipped To):</div>
            ${data.shipping.enabled ? `
              <div style="font-size: 9.5pt; font-weight: 700; margin: 2px 0;">${data.shipping.name || data.client.name || '-'}</div>
              <div style="white-space: pre-line; line-height: 1.35;">${data.shipping.address || data.client.address || '-'}</div>
              <div><strong>State:</strong> ${data.shipping.state || data.client.state || '-'}</div>
            ` : `
              <div style="color: #666; font-style: italic; margin-top: 4px;">Same as Billed To Address</div>
            `}
          </div>
        </div>

        <!-- Items Table -->
        <table style="width: 100%; border-collapse: collapse; font-size: 7.5pt; border-bottom: 1px solid #000;">
          <thead>
            <tr style="background: #f1f5f9; border-bottom: 1px solid #000;">
              <th style="border-right: 1px solid #000; padding: 5px; width: 22px;">S.N.</th>
              <th style="border-right: 1px solid #000; padding: 5px; text-align: left;">Description of Goods / Services</th>
              ${isGST ? `<th style="border-right: 1px solid #000; padding: 5px; width: 65px; text-align: center;">HSN/SAC</th>` : ''}
              <th style="border-right: 1px solid #000; padding: 5px; width: 45px; text-align: center;">Qty</th>
              <th style="border-right: 1px solid #000; padding: 5px; width: 75px; text-align: right;">Rate (₹)</th>
              ${hasDiscount ? `<th style="border-right: 1px solid #000; padding: 5px; width: 55px; text-align: right;">Disc</th>` : ''}
              ${isGST ? `<th style="border-right: 1px solid #000; padding: 5px; width: 75px; text-align: right;">Taxable (₹)</th>` : ''}
              ${isGST ? `<th style="border-right: 1px solid #000; padding: 5px; width: 48px; text-align: center;">GST %</th>` : ''}
              <th style="padding: 5px; width: 80px; text-align: right;">Total (₹)</th>
            </tr>
          </thead>
          <tbody>
            ${data.items.map((item, index) => `
              <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="border-right: 1px solid #000; padding: 5px; text-align: center;">${index + 1}</td>
                <td style="border-right: 1px solid #000; padding: 5px; text-align: left; font-weight: 600;">${item.description || '-'}</td>
                ${isGST ? `<td style="border-right: 1px solid #000; padding: 5px; text-align: center;">${item.hsn || '-'}</td>` : ''}
                <td style="border-right: 1px solid #000; padding: 5px; text-align: center;">${item.quantity || 1}</td>
                <td style="border-right: 1px solid #000; padding: 5px; text-align: right;">${this.formatNumber(item.rate)}</td>
                ${hasDiscount ? `<td style="border-right: 1px solid #000; padding: 5px; text-align: right;">${item.discount > 0 ? this.formatNumber(item.discount) : '-'}</td>` : ''}
                ${isGST ? `<td style="border-right: 1px solid #000; padding: 5px; text-align: right;">${this.formatNumber(item.taxable)}</td>` : ''}
                ${isGST ? `<td style="border-right: 1px solid #000; padding: 5px; text-align: center;">${item.gstRate}%</td>` : ''}
                <td style="padding: 5px; text-align: right; font-weight: 700;">${this.formatNumber(item.total)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <!-- Description / Package Notes Section (Printed below Items Table and above Summary) -->
        ${(data.invoice && data.invoice.description && data.invoice.description.trim()) ? `
          <div style="border: 1px solid #cbd5e1; border-left: 3px solid #334155; padding: 7px; font-size: 8pt; white-space: pre-line; background: #fafafa; line-height: 1.4; margin-bottom: 0;">
            <div style="font-size: 7pt; font-weight: 700; text-transform: uppercase; margin-bottom: 2px;">Notes / Description:</div>
            ${data.invoice.description}
          </div>
        ` : ''}

        <!-- Summary & Totals Block -->
        <div style="display: grid; grid-template-columns: 1.4fr 1fr; border-bottom: 1px solid #000; break-inside: avoid;">
          <div style="padding: 7px; border-right: 1px solid #000; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div style="font-size: 7pt; text-transform: uppercase; font-weight: 700;">Total in Words:</div>
              <div style="font-weight: 800; font-size: 8.5pt; margin: 2px 0;">${data.calculations.amountInWords || 'Zero Rupees Only'}</div>
            </div>

            <!-- Bank & QR -->
            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px dashed #cbd5e1; padding-top: 5px; margin-top: 5px;">
              <div style="font-size: 7pt;">
                <div style="font-weight: 700;">Bank Details for Payment:</div>
                <div>Bank Name: ${data.business.bankName || '-'}</div>
                <div>A/C No: ${data.business.accountNo || '-'}</div>
                <div>IFSC Code: ${data.business.ifsc || '-'}</div>
                ${data.business.upiId ? `<div>UPI ID: ${data.business.upiId}</div>` : ''}
              </div>
              ${qrCodeHtml}
            </div>
          </div>

          <div style="padding: 7px; font-size: 8pt;">
            <div style="display: flex; justify-content: space-between; padding: 2px 0;">
              <span>${isGST ? 'Total Taxable Amount:' : 'Subtotal:'}</span>
              <strong>${this.formatNumber(data.calculations.totalTaxable)}</strong>
            </div>
            ${isGST ? `
              ${isIntra ? `
                <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                  <span>Add: CGST Amount:</span>
                  <span>${this.formatNumber(data.calculations.totalCGST)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                  <span>Add: SGST Amount:</span>
                  <span>${this.formatNumber(data.calculations.totalSGST)}</span>
                </div>
              ` : `
                <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                  <span>Add: IGST Amount:</span>
                  <span>${this.formatNumber(data.calculations.totalIGST)}</span>
                </div>
              `}
            ` : ''}
            ${data.calculations.extraCharges > 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                <span>Freight / Extra Charges:</span>
                <span>${this.formatNumber(data.calculations.extraCharges)}</span>
              </div>
            ` : ''}
            ${data.calculations.roundOff !== 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                <span>Round Off:</span>
                <span>${data.calculations.roundOff > 0 ? '+' : ''}${this.formatNumber(data.calculations.roundOff)}</span>
              </div>
            ` : ''}
            <div style="display: flex; justify-content: space-between; font-size: 10pt; font-weight: 900; border-top: 1px solid #000; margin-top: 4px; padding-top: 4px; background: #f8fafc;">
              <span>Total Invoice Value:</span>
              <span>${this.formatCurrency(data.calculations.grandTotal)}</span>
            </div>
            ${amountPaid > 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 3px 0 1px 0; color: #166534; font-weight: 700; font-size: 8.5pt;">
                <span>Less Received:</span>
                <span>- ${this.formatCurrency(amountPaid)}</span>
              </div>
              ${balanceDue <= 0.01 ? `
                <div style="display: flex; justify-content: space-between; font-size: 9.5pt; font-weight: 900; color: #166534; background: #dcfce7; border-top: 1px solid #000; margin-top: 2px; padding: 3px 4px;">
                  <span>Status:</span>
                  <span>✓ Fully Paid</span>
                </div>
              ` : `
                <div style="display: flex; justify-content: space-between; font-size: 10pt; font-weight: 900; color: #dc2626; border-top: 1px solid #000; margin-top: 2px; padding-top: 2px;">
                  <span>Balance Due:</span>
                  <span>${this.formatCurrency(balanceDue)}</span>
                </div>
              `}
            ` : ''}
          </div>
        </div>

        <!-- HSN Summary Table (Only if GST) -->
        <div style="padding: 5px 7px;">
          ${hsnTableHtml}
        </div>

        <!-- Terms & Signature Footer -->
        <div style="display: grid; grid-template-columns: 1.4fr 1fr; border-top: 1px solid #000; break-inside: avoid;">
          <div style="padding: 7px; border-right: 1px solid #000; font-size: 7pt;">
            <div style="font-weight: 700; text-transform: uppercase;">Terms & Conditions:</div>
            <div style="white-space: pre-line; margin-top: 2px; line-height: 1.35;">
              ${data.invoice.terms || '1. Goods / services once delivered are non-refundable unless agreed in writing.\n2. Payment due within specified due date. Delayed payments may attract interest.\n3. Disputes subject to jurisdiction of seller\'s registered place of business.\n4. This is a computer-generated invoice and is valid without a physical signature.'}
            </div>
          </div>

          <div style="padding: 7px; text-align: center; font-size: 7.5pt; display: flex; flex-direction: column; justify-content: space-between;">
            <div style="font-weight: 700;">For ${data.business.name || 'Company Name'}</div>
            <div style="margin: 8px 0;">
              ${data.business.signature ? `<img src="${data.business.signature}" style="max-height: 45px; max-width: 130px; object-fit: contain;">` : '<div style="height: 32px;"></div>'}
            </div>
            <div style="font-weight: 600;">Authorized Signatory</div>
          </div>
        </div>
      </div>
    `;
  },

  // ==========================================
  // 3. EXECUTIVE CORPORATE TEMPLATE
  // ==========================================
  renderCorporate(data, accentColor) {
    const isGST = data.gstEnabled !== false;
    const isIntra = isGST && data.calculations.isIntraState;
    const hasDiscount = data.discountEnabled === true;
    const qrCodeHtml = this.renderQRCode(data, accentColor);
    const hsnTableHtml = this.renderHSNSummary(data, accentColor);
    const invoiceTitle = this.getInvoiceTitle(data);
    const amountPaid = Number((data.payment && data.payment.amountPaid) || 0);
    const balanceDue = Math.max(0, Number((data.calculations && data.calculations.grandTotal) || 0) - amountPaid);

    return `
      <div style="font-family: inherit; color: #1e293b; line-height: 1.4; font-size: 8.5pt;">
        <!-- Top Band Header -->
        <div style="background: ${accentColor}; color: #ffffff; padding: 14px 18px; border-radius: 6px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
          <div>
            <h1 style="font-size: 16pt; font-weight: 800; margin: 0; color: #ffffff; letter-spacing: -0.01em;">
              ${data.business.name || 'Company Name'}
            </h1>
            <div style="font-size: 8pt; opacity: 0.9; margin-top: 3px;">
              ${(isGST && data.business.gstin) ? `GSTIN: ${data.business.gstin} | ` : ''}
              ${data.business.state ? `State: ${data.business.state}` : ''}
            </div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 14pt; font-weight: 900; letter-spacing: 0.05em; text-transform: uppercase;">
              ${invoiceTitle}
            </div>
            <div style="font-size: 8.5pt; opacity: 0.9; margin-top: 2px;">
              # ${data.invoice.number || 'INV-001'}
            </div>
          </div>
        </div>

        <!-- Meta Info Row -->
        <div style="display: flex; justify-content: space-between; font-size: 8pt; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 12px; margin-bottom: 12px;">
          <div><span style="color: #64748b;">Invoice Date:</span> <strong>${data.invoice.date || '-'}</strong></div>
          <div><span style="color: #64748b;">Due Date:</span> <strong>${data.invoice.dueDate || '-'}</strong></div>
          ${isGST ? `<div><span style="color: #64748b;">Place of Supply:</span> <strong>${data.invoice.placeOfSupply || data.client.state || '-'}</strong></div>` : ''}
          ${isGST ? `<div><span style="color: #64748b;">Reverse Charge:</span> <strong>${data.invoice.reverseCharge || 'No'}</strong></div>` : ''}
        </div>

        <!-- Parties Two Columns -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 14px; font-size: 8pt;">
          <div style="border-left: 3px solid ${accentColor}; padding-left: 10px;">
            <div style="font-weight: 700; color: ${accentColor}; text-transform: uppercase; font-size: 7.5pt; margin-bottom: 2px;">
              Invoice From
            </div>
            <div style="font-weight: 700; font-size: 9.5pt;">${data.business.name || ''}</div>
            <div style="color: #475569; white-space: pre-line;">${data.business.address || ''}</div>
            ${data.business.email ? `<div>Email: ${data.business.email}</div>` : ''}
            ${data.business.phone ? `<div>Phone: ${data.business.phone}</div>` : ''}
          </div>

          <div style="border-left: 3px solid #64748b; padding-left: 10px;">
            <div style="font-weight: 700; color: #475569; text-transform: uppercase; font-size: 7.5pt; margin-bottom: 2px;">
              Invoice To
            </div>
            <div style="font-weight: 700; font-size: 9.5pt;">${data.client.name || 'Client Name'}</div>
            <div style="color: #475569; white-space: pre-line;">${data.client.address || ''}</div>
            ${(isGST && data.client.gstin) ? `<div>GSTIN: ${data.client.gstin}</div>` : ''}
            <div>State: ${data.client.state || '-'}</div>
            ${data.client.phone ? `<div>Phone: ${data.client.phone}</div>` : ''}
          </div>
        </div>

        <!-- Items Table -->
        <table style="width: 100%; border-collapse: collapse; font-size: 8pt; margin-bottom: 12px;">
          <thead>
            <tr style="border-bottom: 2px solid ${accentColor}; color: ${accentColor}; font-weight: 700;">
              <th style="padding: 7px 5px; text-align: center; width: 25px;">#</th>
              <th style="padding: 7px 5px; text-align: left;">Item & Description</th>
              ${isGST ? `<th style="padding: 7px 5px; text-align: center; width: 68px;">HSN/SAC</th>` : ''}
              <th style="padding: 7px 5px; text-align: center; width: 50px;">Qty</th>
              <th style="padding: 7px 5px; text-align: right; width: 80px;">Rate (₹)</th>
              ${hasDiscount ? `<th style="padding: 7px 5px; text-align: right; width: 55px;">Disc</th>` : ''}
              ${isGST ? `<th style="padding: 7px 5px; text-align: right; width: 80px;">Taxable (₹)</th>` : ''}
              ${isGST ? `<th style="padding: 7px 5px; text-align: center; width: 50px;">GST %</th>` : ''}
              <th style="padding: 7px 5px; text-align: right; width: 90px;">Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            ${data.items.map((item, index) => `
              <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="padding: 6px 5px; text-align: center; color: #64748b;">${index + 1}</td>
                <td style="padding: 6px 5px; text-align: left; font-weight: 600; color: #0f172a;">${item.description || '-'}</td>
                ${isGST ? `<td style="padding: 6px 5px; text-align: center; color: #64748b;">${item.hsn || '-'}</td>` : ''}
                <td style="padding: 6px 5px; text-align: center;">${item.quantity || 1}</td>
                <td style="padding: 6px 5px; text-align: right;">${this.formatNumber(item.rate)}</td>
                ${hasDiscount ? `<td style="padding: 6px 5px; text-align: right; color: #dc2626;">${item.discount > 0 ? this.formatNumber(item.discount) : '-'}</td>` : ''}
                ${isGST ? `<td style="padding: 6px 5px; text-align: right;">${this.formatNumber(item.taxable)}</td>` : ''}
                ${isGST ? `<td style="padding: 6px 5px; text-align: center; font-weight: 600;">${item.gstRate}%</td>` : ''}
                <td style="padding: 6px 5px; text-align: right; font-weight: 700;">${this.formatNumber(item.total)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <!-- Description / Package Notes Section (Printed below Items Table and above Totals) -->
        ${(data.invoice && data.invoice.description && data.invoice.description.trim()) ? `
          <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-left: 3px solid ${accentColor}; border-radius: 4px; padding: 8px 12px; margin-bottom: 12px; font-size: 8pt; color: #334155; white-space: pre-line; line-height: 1.45;">
            <div style="font-size: 7pt; font-weight: 700; text-transform: uppercase; color: ${accentColor}; margin-bottom: 2px;">Notes / Description:</div>
            ${data.invoice.description}
          </div>
        ` : ''}

        <!-- Totals & Banking -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 15px; margin-bottom: 12px; break-inside: avoid;">
          <div style="flex: 1; font-size: 8pt;">
            <div style="background: #f1f5f9; padding: 7px 10px; border-radius: 4px; margin-bottom: 8px;">
              <span style="font-size: 7pt; font-weight: 700; color: #64748b;">AMOUNT IN WORDS:</span>
              <div style="font-weight: 700; color: #0f172a;">${data.calculations.amountInWords || 'Zero Rupees Only'}</div>
            </div>

            <!-- Payment card -->
            ${(data.business.bankName || data.business.upiId) ? `
              <div style="border: 1px solid #e2e8f0; border-radius: 4px; padding: 8px 12px; display: flex; justify-content: space-between; align-items: center;">
                <div style="font-size: 7.5pt; color: #334155; line-height: 1.45;">
                  <strong style="color: ${accentColor};">PAYMENT DETAILS:</strong>
                  <div>Bank: ${data.business.bankName || '-'} | A/C: ${data.business.accountNo || '-'}</div>
                  <div>IFSC: ${data.business.ifsc || '-'} | UPI: ${data.business.upiId || '-'}</div>
                </div>
                ${qrCodeHtml}
              </div>
            ` : ''}
          </div>

          <!-- Total Card -->
          <div style="width: 260px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 9px 12px; font-size: 8pt;">
            <div style="display: flex; justify-content: space-between; padding: 2px 0;">
              <span>${isGST ? 'Taxable Value:' : 'Subtotal:'}</span>
              <strong>${this.formatCurrency(data.calculations.totalTaxable)}</strong>
            </div>
            ${isGST ? `
              ${isIntra ? `
                <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                  <span>CGST:</span>
                  <span>${this.formatCurrency(data.calculations.totalCGST)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                  <span>SGST:</span>
                  <span>${this.formatCurrency(data.calculations.totalSGST)}</span>
                </div>
              ` : `
                <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                  <span>IGST:</span>
                  <span>${this.formatCurrency(data.calculations.totalIGST)}</span>
                </div>
              `}
            ` : ''}
            ${data.calculations.extraCharges > 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                <span>Extra Charges:</span>
                <span>${this.formatCurrency(data.calculations.extraCharges)}</span>
              </div>
            ` : ''}
            ${data.calculations.roundOff !== 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                <span>Round Off:</span>
                <span>${data.calculations.roundOff > 0 ? '+' : ''}${this.formatNumber(data.calculations.roundOff)}</span>
              </div>
            ` : ''}
            <div style="background: ${accentColor}; color: #ffffff; border-radius: 4px; padding: 7px 10px; margin-top: 6px; display: flex; justify-content: space-between; align-items: center; font-weight: 800; font-size: 10.5pt;">
              <span>Grand Total:</span>
              <span>${this.formatCurrency(data.calculations.grandTotal)}</span>
            </div>
            ${amountPaid > 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 4px 2px 1px 2px; color: #166534; font-weight: 700; font-size: 8.5pt; margin-top: 4px;">
                <span>Amount Received:</span>
                <span>- ${this.formatCurrency(amountPaid)}</span>
              </div>
              ${balanceDue <= 0.01 ? `
                <div style="display: flex; justify-content: space-between; padding: 3px 6px; background: #dcfce7; color: #166534; font-weight: 800; font-size: 9pt; border-radius: 4px; border-top: 1px solid #bbf7d0; margin-top: 2px;">
                  <span>Payment Status:</span>
                  <span>✓ Fully Paid</span>
                </div>
              ` : `
                <div style="display: flex; justify-content: space-between; padding: 2px; color: #dc2626; font-weight: 800; font-size: 9.5pt; border-top: 1px solid #cbd5e1; margin-top: 2px;">
                  <span>Balance Due:</span>
                  <span>${this.formatCurrency(balanceDue)}</span>
                </div>
              `}
            ` : ''}
          </div>
        </div>

        <!-- HSN Summary Table (Only if GST) -->
        ${hsnTableHtml}

        <!-- Footer -->
        <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-top: 14px; padding-top: 8px; border-top: 1px solid #e2e8f0; break-inside: avoid;">
          <div style="font-size: 7pt; color: #64748b; max-width: 60%;">
            <strong>TERMS & CONDITIONS:</strong><br>
            ${data.invoice.terms || '1. Goods / services once delivered are non-refundable unless agreed in writing.\\n2. Payment due within specified due date. Delayed payments may attract interest.\\n3. Disputes subject to jurisdiction of seller\'s registered place of business.\\n4. This is a computer-generated invoice and is valid without a physical signature.'}
          </div>

          <div style="text-align: center; font-size: 7.5pt;">
            <div style="font-weight: 700; color: #0f172a; margin-bottom: 24px;">For ${data.business.name || 'Company'}</div>
            ${data.business.signature ? `<img src="${data.business.signature}" style="max-height: 45px; max-width: 130px; object-fit: contain;">` : ''}
            <div style="border-top: 1px solid #cbd5e1; padding-top: 2px; font-weight: 600;">Authorized Signatory</div>
          </div>
        </div>
      </div>
    `;
  }
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = { InvoiceTemplates };
}
