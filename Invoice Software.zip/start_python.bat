@echo off
title GST Invoice Pro - Python SQLite Server
cd /d "%~dp0"

echo ========================================================
echo        GST Invoice Pro - Python & Inbuilt SQLite
echo ========================================================
echo.

where python >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python was not found in your system PATH!
    echo Please install Python 3 or ensure it is added to your PATH.
    echo.
    pause
    exit /b 1
)

echo [1/2] Starting Python with Inbuilt SQLite database...
echo [2/2] Your default browser will open automatically.
echo.
echo Database File: data\invoices.db
echo (Keep this window open while using the software)
echo.

python run_server.py

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [Server stopped or encountered an error]
    echo.
)
pause
