"""
GST Invoice Pro - Python Backend & SQLite Database Server
Zero external dependencies required (Uses Python standard library)
"""
import http.server
import socketserver
import urllib.parse
import sqlite3
import json
import os
import sys
import webbrowser

PORT = int(os.environ.get("PORT", 3000))
DIRECTORY = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(DIRECTORY, "data")
DB_PATH = os.path.join(DATA_DIR, "invoices.db")

AUTH_USER = "rudra"
AUTH_PASS = "Rudra@3011"
AUTH_TOKEN = "rudra_auth_token_3011_sec"

os.makedirs(DATA_DIR, exist_ok=True)

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS business_profile (
            id TEXT PRIMARY KEY,
            data TEXT NOT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS invoices (
            id TEXT PRIMARY KEY,
            invoice_number TEXT NOT NULL,
            client_name TEXT,
            date TEXT,
            amount REAL,
            gst_enabled INTEGER,
            data TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
    """)
    conn.commit()
    conn.close()

init_db()

class AppHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def send_json_response(self, status_code, data):
        payload = json.dumps(data).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def is_authenticated(self):
        auth = self.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            token = auth[7:].strip()
            if token == AUTH_TOKEN:
                return True
        return False

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/api/health":
            return self.send_json_response(200, {
                "status": "ok",
                "database": "sqlite"
            })

        if path == "/api/auth-check":
            if self.is_authenticated():
                return self.send_json_response(200, {"authenticated": True, "username": AUTH_USER})
            return self.send_json_response(401, {"authenticated": False, "error": "Unauthorized"})

        # Protect all remaining API routes
        if path.startswith("/api/"):
            if not self.is_authenticated():
                return self.send_json_response(401, {
                    "error": "Unauthorized. Access denied. Please sign in with ID and Password."
                })

        if path == "/api/profile":
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute("SELECT data FROM business_profile WHERE id = 'default'")
            row = cur.fetchone()
            conn.close()
            profile = json.loads(row[0]) if row else None
            return self.send_json_response(200, {"profile": profile})

        if path == "/api/invoices":
            params = urllib.parse.parse_qs(parsed.query)
            search = params.get("search", [""])[0]
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            if search:
                q = f"%{search}%"
                cur.execute("SELECT id, invoice_number, client_name, date, amount, gst_enabled, data, updated_at FROM invoices WHERE invoice_number LIKE ? OR client_name LIKE ? ORDER BY date DESC", (q, q))
            else:
                cur.execute("SELECT id, invoice_number, client_name, date, amount, gst_enabled, data, updated_at FROM invoices ORDER BY date DESC")
            rows = cur.fetchall()
            conn.close()

            invoices = [{
                "id": r[0],
                "invoiceNumber": r[1],
                "clientName": r[2],
                "date": r[3],
                "amount": r[4],
                "gstEnabled": bool(r[5]),
                "data": json.loads(r[6]),
                "savedAt": r[7]
            } for r in rows]
            return self.send_json_response(200, {"count": len(invoices), "invoices": invoices})

        if path == "/api/backup":
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute("SELECT data FROM business_profile WHERE id = 'default'")
            p_row = cur.fetchone()
            profile = json.loads(p_row[0]) if p_row else None

            cur.execute("SELECT id, invoice_number, client_name, date, amount, gst_enabled, data, updated_at FROM invoices ORDER BY date DESC")
            i_rows = cur.fetchall()
            conn.close()

            backup = {
                "version": "2.0",
                "databaseType": "sqlite",
                "defaultProfile": profile,
                "savedInvoices": [{
                    "id": r[0],
                    "invoiceNumber": r[1],
                    "clientName": r[2],
                    "date": r[3],
                    "amount": r[4],
                    "gstEnabled": bool(r[5]),
                    "data": json.loads(r[6]),
                    "savedAt": r[7]
                } for r in i_rows]
            }
            return self.send_json_response(200, backup)

        # Static files
        return super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        length = int(self.headers.get("Content-Length", 0))
        body_raw = self.rfile.read(length).decode("utf-8") if length > 0 else "{}"
        try:
            body = json.loads(body_raw)
        except Exception:
            return self.send_json_response(400, {"error": "Invalid JSON"})

        if path == "/api/login":
            u = str(body.get("username", "")).strip()
            p = str(body.get("password", "")).strip()
            if u == AUTH_USER and p == AUTH_PASS:
                return self.send_json_response(200, {
                    "success": True,
                    "token": AUTH_TOKEN,
                    "username": AUTH_USER,
                    "message": "Login successful"
                })
            return self.send_json_response(401, {
                "success": False,
                "error": "Invalid User ID or Password"
            })

        # Require authentication for all POST endpoints
        if not self.is_authenticated():
            return self.send_json_response(401, {
                "error": "Unauthorized. Access denied. Please sign in with ID and Password."
            })

        if path == "/api/profile":
            profile_data = json.dumps(body.get("profile", body))
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO business_profile (id, data, updated_at)
                VALUES ('default', ?, CURRENT_TIMESTAMP)
                ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = CURRENT_TIMESTAMP
            """, (profile_data,))
            conn.commit()
            conn.close()
            return self.send_json_response(200, {"success": True, "message": "Profile saved to database"})

        if path == "/api/invoices":
            rec = body.get("invoice", body)
            inv_id = str(rec.get("id") or rec.get("invoiceNumber") or "INV-1").strip()
            num = str(rec.get("invoiceNumber") or inv_id).strip()
            client = str(rec.get("clientName") or "Client").strip()
            date = str(rec.get("date") or "")
            amt = float(rec.get("amount") or 0.0)
            gst = 1 if rec.get("gstEnabled") is not False else 0
            data_json = json.dumps(rec.get("data") or rec)

            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO invoices (id, invoice_number, client_name, date, amount, gst_enabled, data, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(id) DO UPDATE SET
                    invoice_number = excluded.invoice_number,
                    client_name = excluded.client_name,
                    date = excluded.date,
                    amount = excluded.amount,
                    gst_enabled = excluded.gst_enabled,
                    data = excluded.data,
                    updated_at = CURRENT_TIMESTAMP
            """, (inv_id, num, client, date, amt, gst, data_json))
            conn.commit()
            conn.close()
            return self.send_json_response(200, {"success": True, "id": inv_id, "message": f"Invoice #{num} saved to database"})

        if path == "/api/backup":
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            if "defaultProfile" in body and body["defaultProfile"]:
                p_str = json.dumps(body["defaultProfile"])
                cur.execute("INSERT INTO business_profile (id, data, updated_at) VALUES ('default', ?, CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET data=excluded.data, updated_at=CURRENT_TIMESTAMP", (p_str,))
            if "savedInvoices" in body and isinstance(body["savedInvoices"], list):
                for inv in body["savedInvoices"]:
                    i_id = str(inv.get("id") or inv.get("invoiceNumber") or "INV").strip()
                    num = str(inv.get("invoiceNumber") or i_id).strip()
                    client = str(inv.get("clientName") or "").strip()
                    date = str(inv.get("date") or "")
                    amt = float(inv.get("amount") or 0.0)
                    gst = 1 if inv.get("gstEnabled") is not False else 0
                    data_json = json.dumps(inv.get("data") or inv)
                    cur.execute("INSERT INTO invoices (id, invoice_number, client_name, date, amount, gst_enabled, data, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET invoice_number=excluded.invoice_number, client_name=excluded.client_name, date=excluded.date, amount=excluded.amount, gst_enabled=excluded.gst_enabled, data=excluded.data, updated_at=CURRENT_TIMESTAMP", (i_id, num, client, date, amt, gst, data_json))
            conn.commit()
            conn.close()
            return self.send_json_response(200, {"success": True, "message": "Database backup restored successfully"})

        return self.send_json_response(404, {"error": "Not found"})

    def do_DELETE(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if not self.is_authenticated():
            return self.send_json_response(401, {"error": "Unauthorized. Please sign in with ID and Password."})
        if path.startswith("/api/invoices/"):
            inv_id = urllib.parse.unquote(path[len("/api/invoices/"):])
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute("DELETE FROM invoices WHERE id = ?", (inv_id,))
            conn.commit()
            conn.close()
            return self.send_json_response(200, {"success": True, "message": "Invoice deleted from database"})
        return self.send_json_response(404, {"error": "Not found"})

class ReusableTCPServer(socketserver.TCPServer):
    allow_reuse_address = True

def get_local_ip():
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip

def find_available_port(start_port=3000, max_attempts=10):
    for offset in range(max_attempts):
        port = start_port + offset
        try:
            with socketserver.TCPServer(("", port), None) as s:
                return port
        except OSError:
            continue
    return start_port

def run():
    os.chdir(DIRECTORY)
    init_db()

    # Try preferred PORT first, then find an available port if busy
    preferred_port = int(os.environ.get("PORT", 3000))
    port = preferred_port
    server = None

    for candidate in [preferred_port, 8000, 8080, 5000]:
        try:
            server = ReusableTCPServer(("", candidate), AppHandler)
            port = candidate
            break
        except OSError:
            continue

    if server is None:
        port = find_available_port(3001)
        server = ReusableTCPServer(("", port), AppHandler)

    url = f"http://localhost:{port}/index.html"
    local_ip = get_local_ip()
    phone_url = f"http://{local_ip}:{port}/index.html"

    print("=" * 65)
    print("  GST INVOICE PRO - PYTHON & INBUILT SQLITE SERVER RUNNING")
    print(f"  PC URL:     {url}")
    if local_ip != "127.0.0.1":
        print(f"  PHONE URL:  {phone_url} (Same Wi-Fi)")
    print(f"  Database:   {DB_PATH}")
    print("=" * 65)
    print("  * On your Phone: Open Chrome/Safari and visit the PHONE URL!")
    print("    No terminal or installation needed on the phone!")
    print("  * Keep this window open while using the software.")
    print("  * Press Ctrl+C in this window anytime to stop the server.")
    print("=" * 65)
    print()

    try:
        webbrowser.open(url)
    except Exception:
        pass

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()

if __name__ == "__main__":
    run()
