// Invoice Templates Engine for Indian Invoices (GST & Non-GST)
// Supports Modern, Classic, and Corporate layouts with dynamic colors

const InvoiceTemplates = {
  // Helper for formatting Indian Rupee currency
  formatCurrency(num) {
    if (num === null || num === undefined || isNaN(num)) return "₹ 0.00";
    return "₹ " + Number(num).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  formatNumber(num) {
    if (num === null || num === undefined || isNaN(num)) return "0.00";
    return Number(num).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  // Generate UPI payment string
  getUPIString(upiId, payeeName, amount, invoiceNo) {
    if (!upiId) return "";
    const cleanId = encodeURIComponent(upiId.trim());
    const name = encodeURIComponent((payeeName || "Business").trim());
    const amt = Number(amount || 0).toFixed(2);
    const note = encodeURIComponent("Invoice " + (invoiceNo || "Payment"));
    return `upi://pay?pa=${cleanId}&pn=${name}&am=${amt}&cu=INR&tn=${note}`;
  },

  // Main render dispatcher
  render(data, templateName = "modern", accentColor = "#1e40af") {
    switch (templateName) {
      case "classic":
        return this.renderClassic(data, accentColor);
      case "corporate":
        return this.renderCorporate(data, accentColor);
      case "modern":
      default:
        return this.renderModern(data, accentColor);
    }
  },

  // Generate QR code SVG or placeholder
  renderQRCode(data) {
    if (!data.business.upiId || typeof QRCodeGenerator === "undefined") {
      return "";
    }
    const upiString = this.getUPIString(
      data.business.upiId,
      data.business.name,
      data.calculations.grandTotal,
      data.invoice.number
    );
    try {
      const qrSvg = QRCodeGenerator.generateSVG(upiString, 88);
      return `
        <div style="display:flex; flex-direction:column; align-items:center; text-align:center; padding:4px;">
          ${qrSvg}
          <span style="font-size:7pt; color:#64748b; margin-top:3px; font-weight:600;">Scan to Pay via UPI</span>
          <span style="font-size:6.5pt; color:#94a3b8;">${data.business.upiId}</span>
        </div>
      `;
    } catch (e) {
      return "";
    }
  },

  // Generate HSN / SAC Tax Summary Table (Only when GST is enabled)
  renderHSNSummary(data, accentColor) {
    if (data.gstEnabled === false) return "";

    const summary = data.calculations.hsnSummary || [];
    if (summary.length === 0) return "";

    const isIntra = data.calculations.isIntraState;

    return `
      <div style="margin-top: 10px; margin-bottom: 10px; break-inside: avoid;">
        <div style="font-size: 7.5pt; font-weight: 700; color: ${accentColor}; text-transform: uppercase; margin-bottom: 4px;">
          HSN / SAC Tax Summary
        </div>
        <table style="width: 100%; border-collapse: collapse; font-size: 7pt; text-align: right;">
          <thead>
            <tr style="background-color: #f8fafc; border-top: 1px solid #cbd5e1; border-bottom: 1px solid #cbd5e1;">
              <th style="padding: 4px; text-align: left;">HSN / SAC</th>
              <th style="padding: 4px;">Taxable Value</th>
              ${isIntra ? `
                <th style="padding: 4px;">CGST Rate</th>
                <th style="padding: 4px;">CGST Amt</th>
                <th style="padding: 4px;">SGST Rate</th>
                <th style="padding: 4px;">SGST Amt</th>
              ` : `
                <th style="padding: 4px;">IGST Rate</th>
                <th style="padding: 4px;">IGST Amt</th>
              `}
              <th style="padding: 4px;">Total Tax</th>
            </tr>
          </thead>
          <tbody>
            ${summary.map(item => `
              <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="padding: 4px; text-align: left; font-weight: 600;">${item.hsn || '-'}</td>
                <td style="padding: 4px;">${this.formatNumber(item.taxable)}</td>
                ${isIntra ? `
                  <td style="padding: 4px;">${item.cgstRate}%</td>
                  <td style="padding: 4px;">${this.formatNumber(item.cgstAmount)}</td>
                  <td style="padding: 4px;">${item.sgstRate}%</td>
                  <td style="padding: 4px;">${this.formatNumber(item.sgstAmount)}</td>
                ` : `
                  <td style="padding: 4px;">${item.igstRate}%</td>
                  <td style="padding: 4px;">${this.formatNumber(item.igstAmount)}</td>
                `}
                <td style="padding: 4px; font-weight: 600;">${this.formatNumber(item.totalTax)}</td>
              </tr>
            `).join('')}
            <tr style="font-weight: 700; background-color: #f8fafc; border-top: 1px solid #cbd5e1;">
              <td style="padding: 4px; text-align: left;">Total</td>
              <td style="padding: 4px;">${this.formatNumber(data.calculations.totalTaxable)}</td>
              ${isIntra ? `
                <td style="padding: 4px;">-</td>
                <td style="padding: 4px;">${this.formatNumber(data.calculations.totalCGST)}</td>
                <td style="padding: 4px;">-</td>
                <td style="padding: 4px;">${this.formatNumber(data.calculations.totalSGST)}</td>
              ` : `
                <td style="padding: 4px;">-</td>
                <td style="padding: 4px;">${this.formatNumber(data.calculations.totalIGST)}</td>
              `}
              <td style="padding: 4px;">${this.formatNumber(data.calculations.totalTax)}</td>
            </tr>
          </tbody>
        </table>
      </div>
    `;
  },

  // Helper for resolved invoice title
  getInvoiceTitle(data) {
    if (data.invoice && data.invoice.title) {
      return data.invoice.title;
    }
    return data.gstEnabled !== false ? "TAX INVOICE" : "INVOICE";
  },

  // ==========================================
  // 1. MODERN MINIMALIST TEMPLATE
  // ==========================================
  renderModern(data, accentColor) {
    const isGST = data.gstEnabled !== false;
    const isIntra = isGST && data.calculations.isIntraState;
    const hasDiscount = data.discountEnabled === true;
    const qrCodeHtml = this.renderQRCode(data);
    const hsnTableHtml = this.renderHSNSummary(data, accentColor);
    const invoiceTitle = this.getInvoiceTitle(data);

    return `
      <div style="font-family: inherit; color: #1e293b; line-height: 1.35;">
        <!-- Top Header: Logo + Company Info & Invoice Badge -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; padding-bottom: 12px; border-bottom: 2px solid ${accentColor};">
          <div style="display: flex; gap: 14px; align-items: center; max-width: 60%;">
            ${data.business.logo ? `
              <img src="${data.business.logo}" alt="Logo" style="max-height: 65px; max-width: 140px; object-fit: contain;">
            ` : ''}
            <div>
              <h1 style="font-size: 14pt; font-weight: 800; color: ${accentColor}; margin: 0; line-height: 1.2;">
                ${data.business.name || 'Your Company Name'}
              </h1>
              <div style="font-size: 7.5pt; color: #475569; margin-top: 4px; white-space: pre-line;">
                ${data.business.address || 'Address Line'}
              </div>
              <div style="font-size: 7.5pt; color: #334155; margin-top: 4px; font-weight: 500;">
                ${(isGST && data.business.gstin) ? `<span><strong>GSTIN:</strong> ${data.business.gstin}</span> | ` : ''}
                ${data.business.state ? `<span><strong>State:</strong> ${data.business.state} ${data.business.stateCode ? `(${data.business.stateCode})` : ''}</span>` : ''}
                ${data.business.pan ? ` | <span><strong>PAN:</strong> ${data.business.pan}</span>` : ''}
              </div>
              <div style="font-size: 7pt; color: #64748b;">
                ${data.business.email ? `Email: ${data.business.email} ` : ''}
                ${data.business.phone ? `| Phone: ${data.business.phone}` : ''}
              </div>
            </div>
          </div>

          <div style="text-align: right;">
            <div style="display: inline-block; background-color: ${accentColor}; color: #ffffff; padding: 4px 12px; border-radius: 4px; font-weight: 700; font-size: 9pt; letter-spacing: 0.05em; text-transform: uppercase;">
              ${invoiceTitle}
            </div>
            <div style="margin-top: 6px; font-size: 8pt;">
              <span style="color: #64748b;">Invoice No:</span> <strong style="color: #0f172a; font-size: 9pt;">${data.invoice.number || 'INV-001'}</strong>
            </div>
            <div style="font-size: 7.5pt; color: #475569; margin-top: 2px;">
              <span>Invoice Date:</span> <strong>${data.invoice.date || '-'}</strong>
            </div>
            ${data.invoice.dueDate ? `
              <div style="font-size: 7.5pt; color: #475569;">
                <span>Due Date:</span> <strong>${data.invoice.dueDate}</strong>
              </div>
            ` : ''}
            ${data.invoice.poNumber ? `
              <div style="font-size: 7.5pt; color: #475569;">
                <span>PO / Ref No:</span> <strong>${data.invoice.poNumber}</strong>
              </div>
            ` : ''}
            ${(isGST && data.invoice.placeOfSupply) ? `
              <div style="font-size: 7.5pt; color: #475569; margin-top: 2px;">
                <span>Place of Supply:</span> <strong>${data.invoice.placeOfSupply}</strong>
              </div>
            ` : ''}
          </div>
        </div>

        <!-- Parties Section: Bill To & Ship To -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 10px; margin-bottom: 12px; font-size: 7.5pt;">
          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 4px; padding: 8px;">
            <div style="font-weight: 700; color: ${accentColor}; text-transform: uppercase; font-size: 7pt; margin-bottom: 3px; letter-spacing: 0.04em;">
              Billed To (Customer Details)
            </div>
            <div style="font-size: 9pt; font-weight: 700; color: #0f172a; margin-bottom: 2px;">
              ${data.client.name || 'Client Name'}
            </div>
            <div style="color: #475569; white-space: pre-line; margin-bottom: 4px;">
              ${data.client.address || 'Client Address'}
            </div>
            ${(isGST && data.client.gstin) ? `<div><strong>GSTIN:</strong> ${data.client.gstin}</div>` : ''}
            ${data.client.state ? `<div><strong>State:</strong> ${data.client.state} ${data.client.stateCode ? `(${data.client.stateCode})` : ''}</div>` : ''}
            ${data.client.phone ? `<div><strong>Phone:</strong> ${data.client.phone}</div>` : ''}
            ${data.client.email ? `<div><strong>Email:</strong> ${data.client.email}</div>` : ''}
          </div>

          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 4px; padding: 8px;">
            <div style="font-weight: 700; color: ${accentColor}; text-transform: uppercase; font-size: 7pt; margin-bottom: 3px; letter-spacing: 0.04em;">
              Shipped To (Delivery Details)
            </div>
            ${data.shipping.enabled ? `
              <div style="font-size: 8.5pt; font-weight: 700; color: #0f172a; margin-bottom: 2px;">
                ${data.shipping.name || data.client.name || '-'}
              </div>
              <div style="color: #475569; white-space: pre-line; margin-bottom: 4px;">
                ${data.shipping.address || data.client.address || '-'}
              </div>
              <div><strong>State:</strong> ${data.shipping.state || data.client.state || '-'}</div>
            ` : `
              <div style="color: #64748b; font-style: italic; margin-top: 4px;">
                Same as Billed To Address
              </div>
            `}
            <div style="margin-top: 6px; padding-top: 4px; border-top: 1px dashed #cbd5e1; font-size: 7pt;">
              ${isGST ? `<div><strong>Reverse Charge:</strong> ${data.invoice.reverseCharge || 'No'}</div>` : ''}
              ${data.invoice.vehicleNo ? `<div><strong>Vehicle / Transport No:</strong> ${data.invoice.vehicleNo}</div>` : ''}
            </div>
          </div>
        </div>

        <!-- Items Table -->
        <table class="inv-items-table" style="width: 100%; border-collapse: collapse; font-size: 7.5pt; margin-bottom: 10px;">
          <thead>
            <tr style="background-color: ${accentColor}; color: #ffffff;">
              <th style="padding: 6px 5px; text-align: center; width: 25px;">#</th>
              <th style="padding: 6px 5px; text-align: left;">Item Description</th>
              ${isGST ? `<th style="padding: 6px 5px; text-align: center; width: 65px;">HSN/SAC</th>` : ''}
              <th style="padding: 6px 5px; text-align: center; width: 50px;">Qty</th>
              <th style="padding: 6px 5px; text-align: right; width: 75px;">Rate (₹)</th>
              ${hasDiscount ? `<th style="padding: 6px 5px; text-align: right; width: 55px;">Disc (₹)</th>` : ''}
              ${isGST ? `<th style="padding: 6px 5px; text-align: right; width: 75px;">Taxable (₹)</th>` : ''}
              ${isGST ? `<th style="padding: 6px 5px; text-align: center; width: 50px;">GST %</th>` : ''}
              <th style="padding: 6px 5px; text-align: right; width: 85px;">Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            ${data.items.map((item, index) => `
              <tr style="border-bottom: 1px solid #e2e8f0; background-color: ${index % 2 === 0 ? '#ffffff' : '#f8fafc'};">
                <td style="padding: 5px; text-align: center; color: #64748b;">${index + 1}</td>
                <td style="padding: 5px; text-align: left; font-weight: 500; color: #0f172a;">
                  ${item.description || '-'}
                </td>
                ${isGST ? `<td style="padding: 5px; text-align: center; color: #475569;">${item.hsn || '-'}</td>` : ''}
                <td style="padding: 5px; text-align: center;">${item.quantity || 1}</td>
                <td style="padding: 5px; text-align: right;">${this.formatNumber(item.rate)}</td>
                ${hasDiscount ? `<td style="padding: 5px; text-align: right; color: #dc2626;">${item.discount > 0 ? this.formatNumber(item.discount) : '-'}</td>` : ''}
                ${isGST ? `<td style="padding: 5px; text-align: right; font-weight: 500;">${this.formatNumber(item.taxable)}</td>` : ''}
                ${isGST ? `<td style="padding: 5px; text-align: center; font-weight: 600;">${item.gstRate}%</td>` : ''}
                <td style="padding: 5px; text-align: right; font-weight: 700; color: #0f172a;">${this.formatNumber(item.total)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <!-- Totals & Calculations Section -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 15px; margin-bottom: 10px; break-inside: avoid;">
          <!-- Left: Amount in words -->
          <div style="flex: 1; font-size: 7.5pt;">
            <div style="background-color: #f1f5f9; padding: 6px 8px; border-radius: 4px; border-left: 3px solid ${accentColor}; margin-bottom: 8px;">
              <div style="font-size: 6.5pt; text-transform: uppercase; font-weight: 700; color: #64748b;">Invoice Amount in Words:</div>
              <div style="font-weight: 700; color: #0f172a; margin-top: 2px;">
                ${data.calculations.amountInWords || 'Zero Rupees Only'}
              </div>
            </div>

            <!-- Bank & Payment Details -->
            ${(data.business.bankName || data.business.accountNo || data.business.upiId) ? `
              <div style="border: 1px solid #e2e8f0; border-radius: 4px; padding: 8px; display: flex; justify-content: space-between; align-items: center; background: #ffffff;">
                <div style="font-size: 7pt; color: #334155; line-height: 1.4;">
                  <div style="font-weight: 700; color: ${accentColor}; text-transform: uppercase; margin-bottom: 2px;">Bank & Payment Details</div>
                  ${data.business.bankName ? `<div><strong>Bank:</strong> ${data.business.bankName}</div>` : ''}
                  ${data.business.accountNo ? `<div><strong>A/C No:</strong> ${data.business.accountNo}</div>` : ''}
                  ${data.business.ifsc ? `<div><strong>IFSC:</strong> ${data.business.ifsc}</div>` : ''}
                  ${data.business.branch ? `<div><strong>Branch:</strong> ${data.business.branch}</div>` : ''}
                  ${data.business.upiId ? `<div><strong>UPI ID:</strong> ${data.business.upiId}</div>` : ''}
                </div>
                ${qrCodeHtml}
              </div>
            ` : ''}
          </div>

          <!-- Right: Summary Totals Card -->
          <div style="width: 250px; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 4px; padding: 8px; font-size: 7.5pt;">
            <div style="display: flex; justify-content: space-between; padding: 2px 0;">
              <span style="color: #64748b;">${isGST ? 'Taxable Subtotal:' : 'Subtotal:'}</span>
              <strong style="color: #0f172a;">${this.formatCurrency(data.calculations.totalTaxable)}</strong>
            </div>

            ${isGST ? `
              ${isIntra ? `
                <div style="display: flex; justify-content: space-between; padding: 2px 0; color: #475569;">
                  <span>Total CGST:</span>
                  <span>+ ${this.formatCurrency(data.calculations.totalCGST)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 2px 0; color: #475569;">
                  <span>Total SGST:</span>
                  <span>+ ${this.formatCurrency(data.calculations.totalSGST)}</span>
                </div>
              ` : `
                <div style="display: flex; justify-content: space-between; padding: 2px 0; color: #475569;">
                  <span>Total IGST:</span>
                  <span>+ ${this.formatCurrency(data.calculations.totalIGST)}</span>
                </div>
              `}
            ` : ''}

            ${data.calculations.extraCharges > 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 2px 0; color: #475569;">
                <span>Additional Charges:</span>
                <span>+ ${this.formatCurrency(data.calculations.extraCharges)}</span>
              </div>
            ` : ''}

            ${data.calculations.roundOff !== 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 2px 0; color: #64748b;">
                <span>Round Off:</span>
                <span>${data.calculations.roundOff > 0 ? '+' : ''}${this.formatNumber(data.calculations.roundOff)}</span>
              </div>
            ` : ''}

            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 2px solid ${accentColor}; margin-top: 5px; padding-top: 5px; font-size: 9pt; font-weight: 800; color: ${accentColor};">
              <span>Grand Total:</span>
              <span style="font-size: 10.5pt;">${this.formatCurrency(data.calculations.grandTotal)}</span>
            </div>
          </div>
        </div>

        <!-- HSN Summary Table (Only if GST) -->
        ${hsnTableHtml}

        <!-- Bottom: Terms & Authorized Signatory -->
        <div style="display: flex; justify-content: space-between; align-items: flex-end; gap: 20px; margin-top: 10px; padding-top: 8px; border-top: 1px solid #e2e8f0; break-inside: avoid;">
          <div style="flex: 1; font-size: 6.5pt; color: #64748b;">
            <div style="font-weight: 700; text-transform: uppercase; color: #475569; margin-bottom: 2px;">Terms & Conditions</div>
            <div style="white-space: pre-line; line-height: 1.3;">
              ${data.invoice.terms || '1. Goods once sold will not be taken back or exchanged.\n2. Subject to local jurisdiction only.\n3. Payment due within specified due date.'}
            </div>
            ${data.invoice.notes ? `
              <div style="margin-top: 4px; font-style: italic;">
                <strong>Note:</strong> ${data.invoice.notes}
              </div>
            ` : ''}
          </div>

          <div style="width: 170px; text-align: center; font-size: 7pt;">
            <div style="font-weight: 700; color: #0f172a; margin-bottom: 20px;">
              For ${data.business.name || 'Company'}
            </div>
            ${data.business.signature ? `
              <img src="${data.business.signature}" alt="Signature" style="max-height: 45px; max-width: 130px; object-fit: contain; margin-bottom: 4px;">
            ` : `
              <div style="height: 35px;"></div>
            `}
            <div style="border-top: 1px dashed #94a3b8; padding-top: 3px; font-weight: 600; color: #334155;">
              Authorized Signatory
            </div>
          </div>
        </div>
      </div>
    `;
  },

  // ==========================================
  // 2. CLASSIC TEMPLATE
  // ==========================================
  renderClassic(data, accentColor) {
    const isGST = data.gstEnabled !== false;
    const isIntra = isGST && data.calculations.isIntraState;
    const hasDiscount = data.discountEnabled === true;
    const qrCodeHtml = this.renderQRCode(data);
    const hsnTableHtml = this.renderHSNSummary(data, accentColor);
    const invoiceTitle = this.getInvoiceTitle(data);

    return `
      <div style="font-family: inherit; color: #000000; font-size: 7.5pt; border: 2px solid #000000; padding: 2px;">
        <!-- Top banner with Copies Checkbox -->
        <div style="border-bottom: 1px solid #000; padding: 4px; display: flex; justify-content: space-between; align-items: center; background: #f8fafc;">
          <div style="font-size: 7pt; font-weight: 600;">
            ${isGST ? `
              [✓] Original for Recipient &nbsp;&nbsp; [ ] Duplicate for Transporter &nbsp;&nbsp; [ ] Triplicate for Supplier
            ` : `
              [✓] Original for Recipient &nbsp;&nbsp; [ ] Duplicate for Records
            `}
          </div>
          <div style="font-size: 11pt; font-weight: 900; letter-spacing: 0.08em; text-transform: uppercase;">
            ${invoiceTitle}
          </div>
        </div>

        <!-- Supplier & Invoice Details Block -->
        <div style="display: grid; grid-template-columns: 1.2fr 1fr; border-bottom: 1px solid #000;">
          <div style="padding: 6px; border-right: 1px solid #000;">
            <div style="font-size: 6.5pt; text-transform: uppercase; font-weight: 700; color: #555;">Details of Supplier / Seller:</div>
            <div style="font-size: 11pt; font-weight: 800; margin: 2px 0;">${data.business.name || 'Business Name'}</div>
            <div style="white-space: pre-line; line-height: 1.3;">${data.business.address || ''}</div>
            ${(isGST && data.business.gstin) ? `<div style="margin-top: 4px;"><strong>GSTIN:</strong> ${data.business.gstin}</div>` : ''}
            <div><strong>State & Code:</strong> ${data.business.state || '-'} (${data.business.stateCode || '-'})</div>
            ${data.business.pan ? `<div><strong>PAN:</strong> ${data.business.pan}</div>` : ''}
            <div><strong>Contact:</strong> ${data.business.phone || ''} ${data.business.email ? `| ${data.business.email}` : ''}</div>
          </div>

          <div style="padding: 6px; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div style="display: flex; justify-content: space-between; margin-bottom: 3px;">
                <span><strong>Invoice No:</strong> ${data.invoice.number || 'INV-001'}</span>
                <span><strong>Date:</strong> ${data.invoice.date || '-'}</span>
              </div>
              ${data.invoice.dueDate ? `<div><strong>Due Date:</strong> ${data.invoice.dueDate}</div>` : ''}
              ${data.invoice.poNumber ? `<div><strong>Order / PO No:</strong> ${data.invoice.poNumber}</div>` : ''}
              ${isGST ? `<div><strong>Place of Supply:</strong> ${data.invoice.placeOfSupply || data.client.state || '-'}</div>` : ''}
              ${isGST ? `<div><strong>Reverse Charge:</strong> ${data.invoice.reverseCharge || 'No'}</div>` : ''}
              ${data.invoice.vehicleNo ? `<div><strong>Vehicle No:</strong> ${data.invoice.vehicleNo}</div>` : ''}
            </div>
            ${data.business.logo ? `
              <div style="text-align: right; margin-top: 4px;">
                <img src="${data.business.logo}" alt="Logo" style="max-height: 40px; max-width: 100px; object-fit: contain;">
              </div>
            ` : ''}
          </div>
        </div>

        <!-- Receiver / Consignee Block -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; border-bottom: 1px solid #000;">
          <div style="padding: 6px; border-right: 1px solid #000;">
            <div style="font-size: 6.5pt; text-transform: uppercase; font-weight: 700; color: #555;">Details of Receiver (Billed To):</div>
            <div style="font-size: 9pt; font-weight: 700; margin: 2px 0;">${data.client.name || 'Client Name'}</div>
            <div style="white-space: pre-line; line-height: 1.3;">${data.client.address || ''}</div>
            ${(isGST && data.client.gstin) ? `<div style="margin-top: 2px;"><strong>GSTIN:</strong> ${data.client.gstin}</div>` : ''}
            <div><strong>State & Code:</strong> ${data.client.state || '-'} (${data.client.stateCode || '-'})</div>
            ${data.client.phone ? `<div><strong>Phone:</strong> ${data.client.phone}</div>` : ''}
          </div>

          <div style="padding: 6px;">
            <div style="font-size: 6.5pt; text-transform: uppercase; font-weight: 700; color: #555;">Details of Consignee (Shipped To):</div>
            ${data.shipping.enabled ? `
              <div style="font-size: 9pt; font-weight: 700; margin: 2px 0;">${data.shipping.name || data.client.name || '-'}</div>
              <div style="white-space: pre-line; line-height: 1.3;">${data.shipping.address || data.client.address || '-'}</div>
              <div><strong>State & Code:</strong> ${data.shipping.state || data.client.state || '-'}</div>
            ` : `
              <div style="color: #666; font-style: italic; margin-top: 4px;">Same as Billed To Address</div>
            `}
          </div>
        </div>

        <!-- Items Table -->
        <table style="width: 100%; border-collapse: collapse; font-size: 7pt; border-bottom: 1px solid #000;">
          <thead>
            <tr style="background: #f1f5f9; border-bottom: 1px solid #000;">
              <th style="border-right: 1px solid #000; padding: 4px; width: 22px;">S.N.</th>
              <th style="border-right: 1px solid #000; padding: 4px; text-align: left;">Description of Goods / Services</th>
              ${isGST ? `<th style="border-right: 1px solid #000; padding: 4px; width: 60px; text-align: center;">HSN/SAC</th>` : ''}
              <th style="border-right: 1px solid #000; padding: 4px; width: 45px; text-align: center;">Qty</th>
              <th style="border-right: 1px solid #000; padding: 4px; width: 70px; text-align: right;">Rate (₹)</th>
              ${hasDiscount ? `<th style="border-right: 1px solid #000; padding: 4px; width: 50px; text-align: right;">Disc</th>` : ''}
              ${isGST ? `<th style="border-right: 1px solid #000; padding: 4px; width: 70px; text-align: right;">Taxable (₹)</th>` : ''}
              ${isGST ? `<th style="border-right: 1px solid #000; padding: 4px; width: 45px; text-align: center;">GST %</th>` : ''}
              <th style="padding: 4px; width: 75px; text-align: right;">Total (₹)</th>
            </tr>
          </thead>
          <tbody>
            ${data.items.map((item, index) => `
              <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="border-right: 1px solid #000; padding: 4px; text-align: center;">${index + 1}</td>
                <td style="border-right: 1px solid #000; padding: 4px; text-align: left; font-weight: 600;">${item.description || '-'}</td>
                ${isGST ? `<td style="border-right: 1px solid #000; padding: 4px; text-align: center;">${item.hsn || '-'}</td>` : ''}
                <td style="border-right: 1px solid #000; padding: 4px; text-align: center;">${item.quantity || 1}</td>
                <td style="border-right: 1px solid #000; padding: 4px; text-align: right;">${this.formatNumber(item.rate)}</td>
                ${hasDiscount ? `<td style="border-right: 1px solid #000; padding: 4px; text-align: right;">${item.discount > 0 ? this.formatNumber(item.discount) : '-'}</td>` : ''}
                ${isGST ? `<td style="border-right: 1px solid #000; padding: 4px; text-align: right;">${this.formatNumber(item.taxable)}</td>` : ''}
                ${isGST ? `<td style="border-right: 1px solid #000; padding: 4px; text-align: center;">${item.gstRate}%</td>` : ''}
                <td style="padding: 4px; text-align: right; font-weight: 700;">${this.formatNumber(item.total)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <!-- Summary & Totals Block -->
        <div style="display: grid; grid-template-columns: 1.4fr 1fr; border-bottom: 1px solid #000; break-inside: avoid;">
          <div style="padding: 6px; border-right: 1px solid #000; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div style="font-size: 6.5pt; text-transform: uppercase; font-weight: 700;">Total in Words:</div>
              <div style="font-weight: 800; font-size: 8pt; margin: 2px 0;">${data.calculations.amountInWords || 'Zero Rupees Only'}</div>
            </div>

            <!-- Bank & QR -->
            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px dashed #cbd5e1; padding-top: 4px; margin-top: 4px;">
              <div style="font-size: 6.5pt;">
                <div style="font-weight: 700;">Bank Details for Payment:</div>
                <div>Bank Name: ${data.business.bankName || '-'}</div>
                <div>A/C No: ${data.business.accountNo || '-'}</div>
                <div>IFSC Code: ${data.business.ifsc || '-'}</div>
                ${data.business.upiId ? `<div>UPI ID: ${data.business.upiId}</div>` : ''}
              </div>
              ${qrCodeHtml}
            </div>
          </div>

          <div style="padding: 6px; font-size: 7.5pt;">
            <div style="display: flex; justify-content: space-between; padding: 2px 0;">
              <span>${isGST ? 'Total Taxable Amount:' : 'Subtotal:'}</span>
              <strong>${this.formatNumber(data.calculations.totalTaxable)}</strong>
            </div>
            ${isGST ? `
              ${isIntra ? `
                <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                  <span>Add: CGST Amount:</span>
                  <span>${this.formatNumber(data.calculations.totalCGST)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                  <span>Add: SGST Amount:</span>
                  <span>${this.formatNumber(data.calculations.totalSGST)}</span>
                </div>
              ` : `
                <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                  <span>Add: IGST Amount:</span>
                  <span>${this.formatNumber(data.calculations.totalIGST)}</span>
                </div>
              `}
            ` : ''}
            ${data.calculations.extraCharges > 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                <span>Freight / Extra Charges:</span>
                <span>${this.formatNumber(data.calculations.extraCharges)}</span>
              </div>
            ` : ''}
            ${data.calculations.roundOff !== 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                <span>Round Off:</span>
                <span>${data.calculations.roundOff > 0 ? '+' : ''}${this.formatNumber(data.calculations.roundOff)}</span>
              </div>
            ` : ''}
            <div style="display: flex; justify-content: space-between; font-size: 9.5pt; font-weight: 900; border-top: 1px solid #000; margin-top: 4px; padding-top: 4px; background: #f8fafc;">
              <span>Total Invoice Value:</span>
              <span>${this.formatCurrency(data.calculations.grandTotal)}</span>
            </div>
          </div>
        </div>

        <!-- HSN Summary Table (Only if GST) -->
        <div style="padding: 4px 6px;">
          ${hsnTableHtml}
        </div>

        <!-- Terms & Signature Footer -->
        <div style="display: grid; grid-template-columns: 1.4fr 1fr; border-top: 1px solid #000; break-inside: avoid;">
          <div style="padding: 6px; border-right: 1px solid #000; font-size: 6.5pt;">
            <div style="font-weight: 700; text-transform: uppercase;">Terms & Conditions:</div>
            <div style="white-space: pre-line; margin-top: 2px;">
              ${data.invoice.terms || '1. Goods once sold will not be accepted back.\n2. Delayed payments may incur interest.\n3. Subject to jurisdiction.'}
            </div>
          </div>

          <div style="padding: 6px; text-align: center; font-size: 7pt; display: flex; flex-direction: column; justify-content: space-between;">
            <div style="font-weight: 700;">For ${data.business.name || 'Company Name'}</div>
            <div style="margin: 8px 0;">
              ${data.business.signature ? `<img src="${data.business.signature}" style="max-height: 40px; max-width: 120px; object-fit: contain;">` : '<div style="height: 30px;"></div>'}
            </div>
            <div style="font-weight: 600;">Authorized Signatory</div>
          </div>
        </div>
      </div>
    `;
  },

  // ==========================================
  // 3. EXECUTIVE CORPORATE TEMPLATE
  // ==========================================
  renderCorporate(data, accentColor) {
    const isGST = data.gstEnabled !== false;
    const isIntra = isGST && data.calculations.isIntraState;
    const hasDiscount = data.discountEnabled === true;
    const qrCodeHtml = this.renderQRCode(data);
    const hsnTableHtml = this.renderHSNSummary(data, accentColor);
    const invoiceTitle = this.getInvoiceTitle(data);

    return `
      <div style="font-family: inherit; color: #1e293b; line-height: 1.35;">
        <!-- Top Band Header -->
        <div style="background: ${accentColor}; color: #ffffff; padding: 14px 16px; border-radius: 6px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
          <div>
            <h1 style="font-size: 15pt; font-weight: 800; margin: 0; color: #ffffff; letter-spacing: -0.01em;">
              ${data.business.name || 'Company Name'}
            </h1>
            <div style="font-size: 7.5pt; opacity: 0.9; margin-top: 3px;">
              ${(isGST && data.business.gstin) ? `GSTIN: ${data.business.gstin} | ` : ''}
              ${data.business.state ? `State: ${data.business.state}` : ''}
            </div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 14pt; font-weight: 900; letter-spacing: 0.05em; text-transform: uppercase;">
              ${invoiceTitle}
            </div>
            <div style="font-size: 8pt; opacity: 0.9; margin-top: 2px;">
              # ${data.invoice.number || 'INV-001'}
            </div>
          </div>
        </div>

        <!-- Meta Info Row -->
        <div style="display: flex; justify-content: space-between; font-size: 7.5pt; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 12px; margin-bottom: 12px;">
          <div><span style="color: #64748b;">Invoice Date:</span> <strong>${data.invoice.date || '-'}</strong></div>
          <div><span style="color: #64748b;">Due Date:</span> <strong>${data.invoice.dueDate || '-'}</strong></div>
          ${isGST ? `<div><span style="color: #64748b;">Place of Supply:</span> <strong>${data.invoice.placeOfSupply || data.client.state || '-'}</strong></div>` : ''}
          ${isGST ? `<div><span style="color: #64748b;">Reverse Charge:</span> <strong>${data.invoice.reverseCharge || 'No'}</strong></div>` : ''}
        </div>

        <!-- Parties Two Columns -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 14px; font-size: 7.5pt;">
          <div style="border-left: 3px solid ${accentColor}; padding-left: 8px;">
            <div style="font-weight: 700; color: ${accentColor}; text-transform: uppercase; font-size: 7pt; margin-bottom: 2px;">
              Invoice From
            </div>
            <div style="font-weight: 700; font-size: 8.5pt;">${data.business.name || ''}</div>
            <div style="color: #475569; white-space: pre-line;">${data.business.address || ''}</div>
            ${data.business.email ? `<div>Email: ${data.business.email}</div>` : ''}
            ${data.business.phone ? `<div>Phone: ${data.business.phone}</div>` : ''}
          </div>

          <div style="border-left: 3px solid #64748b; padding-left: 8px;">
            <div style="font-weight: 700; color: #475569; text-transform: uppercase; font-size: 7pt; margin-bottom: 2px;">
              Invoice To
            </div>
            <div style="font-weight: 700; font-size: 8.5pt;">${data.client.name || 'Client Name'}</div>
            <div style="color: #475569; white-space: pre-line;">${data.client.address || ''}</div>
            ${(isGST && data.client.gstin) ? `<div>GSTIN: ${data.client.gstin}</div>` : ''}
            <div>State: ${data.client.state || '-'} (${data.client.stateCode || '-'})</div>
            ${data.client.phone ? `<div>Phone: ${data.client.phone}</div>` : ''}
          </div>
        </div>

        <!-- Items Table -->
        <table style="width: 100%; border-collapse: collapse; font-size: 7.5pt; margin-bottom: 12px;">
          <thead>
            <tr style="border-bottom: 2px solid ${accentColor}; color: ${accentColor}; font-weight: 700;">
              <th style="padding: 6px 4px; text-align: center; width: 25px;">#</th>
              <th style="padding: 6px 4px; text-align: left;">Item & Description</th>
              ${isGST ? `<th style="padding: 6px 4px; text-align: center; width: 65px;">HSN/SAC</th>` : ''}
              <th style="padding: 6px 4px; text-align: center; width: 50px;">Qty</th>
              <th style="padding: 6px 4px; text-align: right; width: 75px;">Rate (₹)</th>
              ${hasDiscount ? `<th style="padding: 6px 4px; text-align: right; width: 55px;">Disc</th>` : ''}
              ${isGST ? `<th style="padding: 6px 4px; text-align: right; width: 75px;">Taxable (₹)</th>` : ''}
              ${isGST ? `<th style="padding: 6px 4px; text-align: center; width: 50px;">GST %</th>` : ''}
              <th style="padding: 6px 4px; text-align: right; width: 85px;">Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            ${data.items.map((item, index) => `
              <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="padding: 6px 4px; text-align: center; color: #64748b;">${index + 1}</td>
                <td style="padding: 6px 4px; text-align: left; font-weight: 600; color: #0f172a;">${item.description || '-'}</td>
                ${isGST ? `<td style="padding: 6px 4px; text-align: center; color: #64748b;">${item.hsn || '-'}</td>` : ''}
                <td style="padding: 6px 4px; text-align: center;">${item.quantity || 1}</td>
                <td style="padding: 6px 4px; text-align: right;">${this.formatNumber(item.rate)}</td>
                ${hasDiscount ? `<td style="padding: 6px 4px; text-align: right; color: #dc2626;">${item.discount > 0 ? this.formatNumber(item.discount) : '-'}</td>` : ''}
                ${isGST ? `<td style="padding: 6px 4px; text-align: right;">${this.formatNumber(item.taxable)}</td>` : ''}
                ${isGST ? `<td style="padding: 6px 4px; text-align: center; font-weight: 600;">${item.gstRate}%</td>` : ''}
                <td style="padding: 6px 4px; text-align: right; font-weight: 700;">${this.formatNumber(item.total)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <!-- Totals & Banking -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 15px; margin-bottom: 12px; break-inside: avoid;">
          <div style="flex: 1; font-size: 7.5pt;">
            <div style="background: #f1f5f9; padding: 6px 10px; border-radius: 4px; margin-bottom: 8px;">
              <span style="font-size: 6.5pt; font-weight: 700; color: #64748b;">AMOUNT IN WORDS:</span>
              <div style="font-weight: 700; color: #0f172a;">${data.calculations.amountInWords || 'Zero Rupees Only'}</div>
            </div>

            <!-- Payment card -->
            ${(data.business.bankName || data.business.upiId) ? `
              <div style="border: 1px solid #e2e8f0; border-radius: 4px; padding: 6px 10px; display: flex; justify-content: space-between; align-items: center;">
                <div style="font-size: 7pt; color: #334155;">
                  <strong style="color: ${accentColor};">PAYMENT DETAILS:</strong>
                  <div>Bank: ${data.business.bankName || '-'} | A/C: ${data.business.accountNo || '-'}</div>
                  <div>IFSC: ${data.business.ifsc || '-'} | UPI: ${data.business.upiId || '-'}</div>
                </div>
                ${qrCodeHtml}
              </div>
            ` : ''}
          </div>

          <!-- Total Card -->
          <div style="width: 250px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 10px; font-size: 7.5pt;">
            <div style="display: flex; justify-content: space-between; padding: 2px 0;">
              <span>${isGST ? 'Taxable Value:' : 'Subtotal:'}</span>
              <strong>${this.formatCurrency(data.calculations.totalTaxable)}</strong>
            </div>
            ${isGST ? `
              ${isIntra ? `
                <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                  <span>CGST:</span>
                  <span>${this.formatCurrency(data.calculations.totalCGST)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                  <span>SGST:</span>
                  <span>${this.formatCurrency(data.calculations.totalSGST)}</span>
                </div>
              ` : `
                <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                  <span>IGST:</span>
                  <span>${this.formatCurrency(data.calculations.totalIGST)}</span>
                </div>
              `}
            ` : ''}
            ${data.calculations.extraCharges > 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                <span>Extra Charges:</span>
                <span>${this.formatCurrency(data.calculations.extraCharges)}</span>
              </div>
            ` : ''}
            ${data.calculations.roundOff !== 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 2px 0;">
                <span>Round Off:</span>
                <span>${data.calculations.roundOff > 0 ? '+' : ''}${this.formatNumber(data.calculations.roundOff)}</span>
              </div>
            ` : ''}
            <div style="background: ${accentColor}; color: #ffffff; border-radius: 4px; padding: 6px 8px; margin-top: 6px; display: flex; justify-content: space-between; align-items: center; font-weight: 800; font-size: 10pt;">
              <span>Grand Total:</span>
              <span>${this.formatCurrency(data.calculations.grandTotal)}</span>
            </div>
          </div>
        </div>

        <!-- HSN Summary Table (Only if GST) -->
        ${hsnTableHtml}

        <!-- Footer -->
        <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-top: 14px; padding-top: 8px; border-top: 1px solid #e2e8f0; break-inside: avoid;">
          <div style="font-size: 6.5pt; color: #64748b; max-width: 60%;">
            <strong>TERMS & CONDITIONS:</strong><br>
            ${data.invoice.terms || 'Subject to local jurisdiction. Goods once sold cannot be returned.'}
          </div>

          <div style="text-align: center; font-size: 7pt;">
            <div style="font-weight: 700; color: #0f172a; margin-bottom: 24px;">For ${data.business.name || 'Company'}</div>
            ${data.business.signature ? `<img src="${data.business.signature}" style="max-height: 40px; max-width: 120px; object-fit: contain;">` : ''}
            <div style="border-top: 1px solid #cbd5e1; padding-top: 2px; font-weight: 600;">Authorized Signatory</div>
          </div>
        </div>
      </div>
    `;
  }
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = { InvoiceTemplates };
}
